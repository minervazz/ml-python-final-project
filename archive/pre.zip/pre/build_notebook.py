"""Builds zindi_engagement.ipynb (slide-annotated). Run: python build_notebook.py"""
import re
import nbformat as nbf

cells = []


def md(src, slide='slide'):
    # pandoc (PDF export) needs a blank line before a list that follows a paragraph
    lines, out = src.strip().split('\n'), []
    item = re.compile(r'^(- |\d+\. )')
    for i, l in enumerate(lines):
        if i and item.match(l) and lines[i - 1].strip() and not item.match(lines[i - 1]) and not lines[i - 1].startswith(' '):
            out.append('')
        out.append(l)
    c = nbf.v4.new_markdown_cell('\n'.join(out))
    c.metadata['slideshow'] = {'slide_type': slide}
    cells.append(c)


def code(src, slide='-', hide=False):
    c = nbf.v4.new_code_cell(src.strip())
    c.metadata['slideshow'] = {'slide_type': slide}
    if hide:
        c.metadata['tags'] = ['hide_input']
    cells.append(c)


# =====================================================================
md(r"""
# Predicting New-User Engagement on Zindi
### Will a user who just signed up still be active in their second month?

Data: [Zindi New User Engagement Prediction Challenge](https://zindi.africa/competitions/zindi-new-user-engagement-prediction-challenge) (Zindi, 2022–23)

**Outline**
1. Problem & data (load, build target, X / y)
2. Data preparation: encoding, missing values, feature engineering
3. Exploratory analysis with Seaborn → what it changes in the ML setup
4. Validation design & metric
5. Models, hyper-parameter search, results
6. Findings, real-world impact, conclusions
""")

md(r"""
## 1. The problem

**Zindi** is Africa's largest data-science competition platform ($\approx$ 12 k new sign-ups in the 7 months of this dataset).
Most sign-ups are *one-month tourists*: in our data only **12–21 %** of a typical monthly cohort comes back in its second month.

**Task.** For every user who registered in month *m*, predict whether they will do **anything** on Zindi
(view a page, join a competition, submit, post…) in month *m + 1*. → binary classification.

**Why it matters**
- Acquisition is expensive; a user who survives month 2 is far more likely to become a long-term community member, competitor and potential hire for Zindi's clients.
- Churn happens fast. Zindi needs to know **at the end of the first month** who is about to drop out, while there is still time to act.

**How the model helps**
- *Targeted retention*: send onboarding nudges / beginner competitions / mentorship to users with low predicted probability instead of spamming everybody → lower cost, less unsubscribe fatigue.
- *Prioritisation*: identify likely-engaged newcomers for community programmes and hackathon invitations.
- *Product insight*: which first-month behaviours drive retention (e.g. submitting vs. only browsing)?
""")

md(r"""
## 1.1 Loading the data with pandas

Eight relational tables, linked by `User_ID` / `Competition ID`. Dates are **masked**: year and month are recoded
("*months are in chronological order but January is not necessarily month 1*"), time of day and day-of-month are kept.
""")

code(r"""
import warnings; warnings.filterwarnings('ignore')
import numpy as np, pandas as pd, matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_predict
from sklearn.metrics import (f1_score, precision_score, recall_score, average_precision_score,
                             roc_auc_score, precision_recall_curve, confusion_matrix)
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler, FunctionTransformer
from sklearn.inspection import permutation_importance
from sklearn.base import clone
sns.set_theme(style='whitegrid', context='notebook', palette='deep')
plt.rcParams.update({'figure.dpi': 110, 'axes.titleweight': 'bold'})
pd.set_option('display.width', 160, 'display.max_columns', 30, 'display.max_colwidth', 120)
pd.set_option('display.latex.repr', True)   # proper tables in the PDF export
RNG = 42
""", hide=True)

code(r"""
D = 'data/'
users = pd.read_csv(D + 'Users.csv')
act   = pd.read_csv(D + 'UserActivity.csv')            # page views / clicks
part  = pd.read_csv(D + 'CompetitionPartipation.csv')  # competition enrolments
disc  = pd.read_csv(D + 'Discussion.csv')
com   = pd.read_csv(D + 'Comments.csv')
comps = pd.read_csv(D + 'Competition.csv')
sample_sub = pd.read_csv(D + 'SampleSubmission.csv')

pd.DataFrame({n: [len(t), t.shape[1]] for n, t in
              dict(Users=users, UserActivity=act, CompetitionParticipation=part,
                   Discussion=disc, Comments=com, Competition=comps).items()},
             index=['rows', 'cols']).T
""")

code(r"""
users.head(3).T          # transposed: one column per user
""")

code(r"""
act.head(3).T
""", slide='fragment')

md(r"""
## 1.2 Recovering the time axis

All users are in masked *Year 1*, with masked months {11, 12, 1, 2, 3, 4, 5}. In what order?
We cross-tabulate **sign-up month** (rows) vs **activity month** (columns): users can only be active *after* they register,
so the zero pattern reveals the chronology.
""")

code(r"""
ORDER = {11: 0, 12: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6}           # masked month -> chronological index t
LABEL = {v: f'M{k}' for k, v in ORDER.items()}                    # t -> display label

def standardise(df, prefix):
    df = df.rename(columns={f'{prefix} Month': 'month', f'{prefix} Day_of_month': 'day', f'{prefix} time': 'time'})
    df['t'] = df['month'].map(ORDER)
    return df

users = standardise(users, 'Created At').rename(columns={'t': 'cohort', 'day': 'signup_day'})
act, part = standardise(act, 'datetime'), standardise(part, 'Created At')
disc, com = standardise(disc, 'Created At'), standardise(com, 'Created At')

am = act.merge(users[['User_ID', 'cohort']], on='User_ID')
ct = pd.crosstab(am.cohort, am.t.rename('activity month'))
ct = ct.rename(index=LABEL, columns=LABEL)
fig, ax = plt.subplots(figsize=(8, 3.6))
sns.heatmap(np.log10(ct + 1), annot=ct, fmt='d', cmap='Blues', cbar_kws={'label': 'log10(#events)'}, ax=ax)
ax.set(ylabel='sign-up cohort', title='Events by sign-up month × activity month'); plt.show()
""")

md(r"""
**Reading the matrix**
- (Almost) upper-triangular — only a few dozen stray events below the diagonal $\Rightarrow$ chronological order is **M11 → M12 → M1 → M2 → M3 → M4 → M5** (7 consecutive months).
- The **M4 cohort has essentially no M5 activity** (8 users out of 1 382): Zindi removed it — the M4 cohort is the
  hidden **test set** (`SampleSubmission` = 1 340 M4 users, "`_Month_5`").
- $\Rightarrow$ We must **build the training labels ourselves** from cohorts M11 … M3 (their month-*m+1* is observed).
""")

md(r"""
## 1.3 Target definition and X / y split

`Active = 1` if the user has **any** record (activity log, competition enrolment, discussion or comment) in the month
right after the sign-up month. Features may only use information from the **sign-up month** (what Zindi knows
at the moment it has to act) — anything later would leak the target.
""")

code(r"""
events = pd.concat([x[['User_ID', 't']] for x in (act, part, disc, com)])
ev = events.merge(users[['User_ID', 'cohort']], on='User_ID')
active_next = set(ev.loc[ev.t == ev.cohort + 1, 'User_ID'])
users['Active'] = users.User_ID.isin(active_next).astype(int)

LABELLED = [0, 1, 2, 3, 4]      # M11..M3 cohorts: label observed
TEST_COHORT = 5                 # M4 cohort: label hidden by Zindi
summary = users[users.cohort <= TEST_COHORT].groupby('cohort').agg(users=('Active', 'size'), active_rate=('Active', 'mean'))
summary.index = summary.index.map(LABEL); summary.loc['M4', 'active_rate'] = np.nan
summary.T.round(3)
""")

# =====================================================================
md(r"""
## 2. Data preparation

| Issue | What we do | Why |
|---|---|---|
| Events are in long, multi-table logs | aggregate per user **within the sign-up month only** | one row per user; no look-ahead leakage |
| 70+ raw event titles (`comp_ID_xxx`, `badge_xxx`, …) | group into 18 behaviour families (view competition, submit, download data, …) | IDs are too sparse; the *type* of behaviour is what generalises |
| `Countries_ID` missing for 47 % of users | category `Missing` + binary flag | missingness is informative (see EDA) — imputing a country would be invented data |
| 146 masked countries (high cardinality) | keep top-10, rest → `Other`, **one-hot** | enough users per level; avoids over-fitting rare countries |
| `FeatureY` $\in$ {0, 1, 3} (masked category) | one-hot | codes are nominal, not ordinal |
| `Successful Submission Count` = strings `"count 10"`, NaN | parse number; NaN → 0 | NaN = no successful submission |
| Users with no events in a table | counts → 0 | absence of activity is a true zero |
| Late sign-ups have less time to show activity | `days_observed`, `active_day_ratio`, `days_since_last` | normalises activity by exposure |
| Month lengths are masked too (M2 has 31 days!), M4 log stops at day 22 | window end = last logged day of that month | keeps exposure features consistent between train and test |
""")

code(r"""
def family(title):
    for p in ('comp_', 'blog_', 'job_', 'badge_'):
        if title.startswith(p):
            return 'view_' + p[:-1]
    return title

act['family'] = act.Title.map(family)
act['comp_id'] = np.where(act.Title.str.startswith('comp_'), act.Title.str[5:], None)
FAMILIES = ['view_comp', 'Viewed All Competitions', 'Viewed All Discussions', 'Viewed All Learning Pages',
            'Downloaded Competition Datafile', 'Updated Profile', 'Created Submission', 'view_badge',
            'Confirmed Email', 'Updated Discussion', 'Joined Competition', 'Viewed All Jobs', 'Signed In',
            'Updated Submission', 'view_blog', 'Signed Out', 'view_job', 'Viewed Discussion']

def first_month(df):
    # keep only events that happen in the user's sign-up month
    df = df.merge(users[['User_ID', 'cohort']], on='User_ID')
    return df[df.t == df.cohort]

a0, p0, d0, c0 = map(first_month, (act, part, disc, com))
""", hide=True)

md(r"""
### Engineered features (all computed from the sign-up month)

- **Volume / regularity**: `n_events`, `n_active_days`, `n_distinct_actions`, `n_distinct_comps`, `active_day_ratio`
- **Recency**: `days_since_last` = days between last activity and month end (fresh activity $\Rightarrow$ likely to continue)
- **Behaviour mix**: counts for 18 event families (submissions, data downloads, learning pages, jobs …)
- **Competition context** (from `CompetitionParticipation` + `Competition`):
  - `n_comps_joined`, `max_sub_bucket` (masked successful-submission bucket)
  - `n_new_comps_joined`: competitions whose **first appearance** in the logs is in the sign-up month — a freshly launched competition is likely still running next month (computed from past/present logs only)
  - `joined_hackathon`: joined a competition that requires a secret code (= hackathon / class event)
- **Community**: `n_discussions`, `n_comments`
- **Profile**: `FeatureX`, `FeatureY`, country, `country_missing`, `signup_day`, `signup_hour`, `days_observed`
""", slide='subslide')

code(r"""
counts = pd.crosstab(a0.User_ID, a0.family).reindex(columns=FAMILIES, fill_value=0)
counts.columns = ['n_' + c.lower().replace(' ', '_') for c in counts.columns]
activity = a0.groupby('User_ID').agg(n_events=('family', 'size'), n_active_days=('day', 'nunique'),
                                     n_distinct_actions=('family', 'nunique'), last_active_day=('day', 'max'),
                                     n_distinct_comps=('comp_id', 'nunique'))

first_seen = pd.concat([part[['Competition ID', 't']],
                        act.dropna(subset=['comp_id']).rename(columns={'comp_id': 'Competition ID'})[['Competition ID', 't']]]
                       ).groupby('Competition ID').t.min()
p0 = p0.assign(new_comp=(p0.t == p0['Competition ID'].map(first_seen)).astype(int),
               hackathon=p0['Competition ID'].map(comps.set_index('Comp_ID').SecretCode),
               sub_bucket=p0['Successful Submission Count'].str.extract(r'(\d+)', expand=False).astype(float))
competition = p0.groupby('User_ID').agg(n_comps_joined=('Competition ID', 'nunique'), max_sub_bucket=('sub_bucket', 'max'),
                                        n_new_comps_joined=('new_comp', 'sum'), joined_hackathon=('hackathon', 'max'))

df = (users.set_index('User_ID')
      .join(activity).join(counts).join(competition)
      .assign(n_discussions=d0.User_ID.value_counts(), n_comments=c0.User_ID.value_counts()))
zero_fill = [c for c in df.columns if c.startswith('n_')] + ['max_sub_bucket', 'joined_hackathon']
df[zero_fill] = df[zero_fill].fillna(0)

obs_end = act.groupby('month').day.max()       # last logged day per month (masked lengths; M4 log stops at day 22)
df['days_observed'] = (df.month.map(obs_end) - df.signup_day + 1).clip(lower=1)
df['days_since_last'] = (df.month.map(obs_end) - df.last_active_day).clip(lower=0).fillna(df.days_observed)
df['active_day_ratio'] = df.n_active_days / df.days_observed
df['signup_hour'] = df.time.str[:2].astype(int)
df['country_missing'] = df.Countries_ID.isna().astype(int)
top10 = df.Countries_ID.value_counts().index[:10]
df['country'] = np.select([df.Countries_ID.isin(top10), df.Countries_ID.isna()], [df.Countries_ID, 'Missing'], 'Other')
df = pd.get_dummies(df, columns=['country', 'FeatureY'], prefix=['cty', 'FY'])
df = df.drop(columns=['Countries_ID', 'time', 'Created At Year', 'month', 'last_active_day'])
print('modelling table:', df.shape, '| remaining NaNs:', int(df.isna().sum().sum()))
""")

code(r"""
FEATURES = [c for c in df.columns if c not in ('Active', 'cohort')]
lab = df[df.cohort.isin(LABELLED)]
X, y = lab[FEATURES], lab['Active']                 # <- inputs / output
X_test = df.loc[df.cohort == TEST_COHORT, FEATURES]  # M4 cohort, label hidden
print(f'X: {X.shape}, y: {y.shape}, positive rate = {y.mean():.3f} | X_test: {X_test.shape}')
X[['n_events', 'n_active_days', 'n_comps_joined', 'n_created_submission', 'days_since_last', 'country_missing']].describe().T.round(2)
""", slide='subslide')

# =====================================================================
md(r"""
## 3. Exploratory analysis — 3.1 retention differs strongly by cohort
""")

code(r"""
fig, axes = plt.subplots(1, 2, figsize=(12, 3.8))
r = lab.assign(cohort=lab.cohort.map(LABEL))
sns.barplot(data=r, x='cohort', y='Active', order=[LABEL[t] for t in LABELLED], ax=axes[0], color='C0')
axes[0].set(title='Share active in month 2, by sign-up cohort', ylabel='P(Active)', xlabel='sign-up cohort')
for p in axes[0].patches: axes[0].annotate(f'{p.get_height():.0%}', (p.get_x() + .4, p.get_height() + .02), ha='center')

m12 = act.merge(users[['User_ID', 'cohort']], on='User_ID').query('cohort == 1 and t == 2')
dau = m12.groupby('day').User_ID.nunique().reset_index()
sns.lineplot(data=dau, x='day', y='User_ID', marker='o', ax=axes[1])
axes[1].set(title='M12 cohort: daily active users during M1', ylabel='active users', xlabel='day of M1'); plt.tight_layout(); plt.show()
""")

md(r"""
- 4 of 5 cohorts retain **12–21 %**, but the **M12 cohort retains 78 %**.
- M12 users' activity in M1 is one **spike on a single day (about 1 500 users on day 15)**, concentrated on competition
  `ID_528W`: a *secret-code hackathon* hosted in country `X9GR`, running from M12-28 to M2-3.
  M12 sign-ups were mostly **event participants**, whose "retention" was mechanically caused by the event.
- **Consequences for ML**
  1. Label prior is not stationary → a random train/test split would mix cohorts and look over-optimistic → **time-based validation**.
  2. The M12 cohort is not representative of the test cohort → we test **excluding it from training** (Section 4).
  3. Motivated two features: `joined_hackathon`, `n_new_comps_joined`.
""")

md(r"""
## 3.2 First-month engagement vs. month-2 activity
""")

code(r"""
normal = lab[lab.cohort != 1]           # typical cohorts
fig, axes = plt.subplots(1, 3, figsize=(14, 3.8))
bins = pd.cut(normal.n_active_days, [-1, 0, 1, 2, 4, 31], labels=['0', '1', '2', '3-4', '5+'])
sns.pointplot(x=bins, y=normal.Active, ax=axes[0], join=False, color='C0')
axes[0].set(xlabel='# active days in sign-up month', ylabel='P(Active next month)', title='Regularity')
sns.boxplot(data=normal, x='Active', y=np.log1p(normal.n_events), ax=axes[1], showfliers=False)
axes[1].set(ylabel='log(1 + #events)', title='Activity volume')
rec = pd.cut(normal.days_since_last, [-1, 2, 7, 14, 31], labels=['0-2', '3-7', '8-14', '15+'])
sns.pointplot(x=rec, y=normal.Active, ax=axes[2], join=False, color='C3')
axes[2].set(xlabel='days since last activity at month end', ylabel='P(Active next month)', title='Recency'); plt.tight_layout(); plt.show()
""")

md(r"""
- Retention rises monotonically with the **number of active days**: 6 % (no logged activity) → 13 % (1 day) → 55 % (5+ days).
- **Recency** is at least as important as volume: users seen in the last 2 days of the month return 39 % of the time, vs 7 % for users silent for 15+ days.
- Distributions are extremely **right-skewed** (median user: a handful of events) → log-transform counts for the linear model; tree models are invariant.
""")

md(r"""
## 3.3 Behaviour types and profile variables
""")

code(r"""
beh = ['n_created_submission', 'n_downloaded_competition_datafile', 'n_joined_competition', 'n_viewed_all_learning_pages',
       'n_viewed_all_jobs', 'n_view_blog', 'n_updated_profile', 'n_discussions', 'joined_hackathon', 'n_new_comps_joined']
rates = pd.DataFrame({b[2:] if b.startswith('n_') else b: normal.groupby(normal[b] > 0).Active.mean() for b in beh}).T
rates.columns = ['did not', 'did']
fig, axes = plt.subplots(1, 2, figsize=(14, 4.2), gridspec_kw={'width_ratios': [1.4, 1]})
rates.sort_values('did').plot.barh(ax=axes[0], color=['#bbbbbb', 'C0'])
axes[0].set(xlabel='P(Active next month)', title='Retention: users who did / did not do X (sign-up month)')

miss = users[users.cohort <= 6].groupby('cohort').apply(lambda g: g.Countries_ID.isna().mean()).rename(index=LABEL)
sns.barplot(x=miss.index, y=miss.values, ax=axes[1], color='C1')
axes[1].set(title='Share of users with missing country', ylabel='missing share', xlabel='sign-up cohort'); plt.tight_layout(); plt.show()
""")

md(r"""
- *Doing* things (submitting, downloading data, joining competitions, posting) predicts retention much better than
  *reading* (blog, jobs pages). → keep the behaviour-family breakdown instead of a single activity count.
- **Country is missing for 10–21 % of users up to M1 and 64–72 % from M2 on** — a change in the sign-up form, not user behaviour.
  `country_missing` is therefore a *time proxy* that can mislead a model trained on old cohorts → we check whether
  dropping country features helps under temporal validation.
""")

code(r"""
corr_feats = ['n_events', 'n_active_days', 'active_day_ratio', 'days_since_last', 'n_distinct_actions', 'n_comps_joined',
              'n_new_comps_joined', 'n_created_submission', 'n_downloaded_competition_datafile', 'n_discussions',
              'signup_day', 'days_observed', 'FeatureX', 'country_missing', 'Active']
c = normal[corr_feats].corr(method='spearman')
fig, ax = plt.subplots(figsize=(9, 6.5))
sns.heatmap(c, mask=np.triu(np.ones_like(c, dtype=bool), 1), cmap='vlag', center=0, annot=True, fmt='.2f',
            annot_kws={'size': 7}, cbar_kws={'shrink': .7}, ax=ax)
ax.set_title('Spearman correlations (typical cohorts)'); plt.show()
""", slide='subslide')

md(r"""
- Activity features are strongly **collinear** ($\rho$ 0.6–0.9) → L2-regularised logistic regression; trees handle it natively.
- The strongest single correlates of `Active` are regularity (`n_active_days`) and recency (`days_since_last`, negative).
- `signup_day` and `days_observed` are mirror images ($\rho$ = −1). Interestingly late sign-ups are *more* likely to be active next month ($\rho$ = +0.13): their first sessions spill over into month 2. The model must see sign-up timing to interpret activity counts correctly.
""")

# =====================================================================
md(r"""
## 4. Validation design and metric

**Cross-validation — forward chaining by cohort** (train on past cohorts, validate on the next one), because
at deployment time the model is trained on past cohorts and applied to a new one; random K-fold would leak cohort-level information.

| split | train cohorts | validate on |
|---|---|---|
| inner fold 1 | M11 (+M12) | M1 |
| inner fold 2 | M11 (+M12), M1 | M2 |
| **hold-out test** | M11 (+M12), M1, M2 | **M3** (never used for tuning) |

Hyper-parameters **and the final model family** are selected on the two inner folds only; the decision threshold is chosen on the inner out-of-fold predictions;
the M3 cohort is scored **once** at the end.

**Metric — F1 of the positive class** (the competition metric): positives are only 12–21 %, so accuracy is useless
(predict "all inactive" → 85 % accuracy, F1 = 0). F1 balances *precision* (don't waste retention budget) and *recall*
(don't miss engaged users). For model selection we use **PR-AUC (average precision)**, which is threshold-free and focuses on the minority class.
""")

code(r"""
coh = lab.cohort.values

def forward_folds(cohorts, val_cohorts=(2, 3), exclude=()):
    # expanding-window folds: train on all earlier cohorts, validate on one cohort
    return [(np.where((cohorts < v) & ~np.isin(cohorts, exclude))[0], np.where(cohorts == v)[0]) for v in val_cohorts]

dev = coh <= 3                              # development cohorts (M11, M12, M1, M2)
hold = coh == 4                             # hold-out cohort (M3)
X_dev, y_dev, coh_dev = X[dev], y[dev], coh[dev]
X_hold, y_hold = X[hold], y[hold]
print('dev:', X_dev.shape, ' hold-out (M3):', X_hold.shape, f' hold-out positive rate {y_hold.mean():.3f}')
""", hide=True)

md(r"""
### Why not random K-fold? — a quick demonstration
""", slide='subslide')

code(r"""
demo = HistGradientBoostingClassifier(random_state=RNG)
p_rand = cross_val_predict(demo, X, y, cv=StratifiedKFold(5, shuffle=True, random_state=RNG), method='predict_proba')[:, 1]
rows = [('random 5-fold (all cohorts mixed)', average_precision_score(y, p_rand))]
for tr, va in forward_folds(coh, val_cohorts=(2, 3, 4)):
    p = clone(demo).fit(X.iloc[tr], y.iloc[tr]).predict_proba(X.iloc[va])[:, 1]
    rows.append((f'forward: train < {LABEL[coh[va][0]]} → validate {LABEL[coh[va][0]]}', average_precision_score(y.iloc[va], p)))
pd.DataFrame(rows, columns=['scheme', 'PR-AUC']).round(3)
""")

md(r"""
Random K-fold reports PR-AUC $\approx$ 0.85; honest forward validation gives $\approx$ 0.3–0.5. Part of the gap is the higher base rate
when M12 is mixed in, but mostly the model **memorises cohort-specific signals** (e.g. which hackathon, whether country is recorded)
that do not transfer to a future cohort. Every number from here on uses forward validation.
""")

# =====================================================================
md(r"""
## 5. Models and hyper-parameter search

| model | why |
|---|---|
| **Heuristic baseline** — "active on $\geq$ *k* days" | what a product manager would do without ML |
| **Logistic regression** (log1p + scaling, L2, class-balanced) | interpretable, robust to shift, handles collinearity via regularisation |
| **Random forest** (class-balanced) | non-linear, robust, few assumptions |
| **Histogram gradient boosting** | state of the art for tabular data, native handling of skewed counts & interactions |

Grid search (`GridSearchCV` with our forward folds, scoring = PR-AUC), then two data-level choices suggested by the EDA:
**(a)** keep or drop the anomalous M12 cohort from training, **(b)** keep or drop country features.
""")

code(r"""
log_lr = make_pipeline(FunctionTransformer(np.log1p), StandardScaler(),
                       LogisticRegression(max_iter=5000, class_weight='balanced'))
SEARCH = {
    'LogReg': (log_lr, {'logisticregression__C': [0.003, 0.01, 0.03, 0.1, 0.3, 1]}),
    'RandomForest': (RandomForestClassifier(n_estimators=400, class_weight='balanced_subsample', n_jobs=-1, random_state=RNG),
                     {'max_depth': [6, 10, None], 'min_samples_leaf': [5, 20, 50], 'max_features': ['sqrt', 0.4]}),
    'GradBoost': (HistGradientBoostingClassifier(random_state=RNG),
                  {'learning_rate': [0.03, 0.1], 'max_iter': [100, 300], 'max_leaf_nodes': [7, 15, 31],
                   'min_samples_leaf': [20, 80], 'l2_regularization': [0.0, 1.0]}),
}
NO_COUNTRY = [f for f in FEATURES if not f.startswith('cty_') and f != 'country_missing']

def search(name, drop_m12, feats):
    est, grid = SEARCH[name]
    folds = forward_folds(coh_dev, exclude=(1,) if drop_m12 else ())
    gs = GridSearchCV(est, grid, scoring='average_precision', cv=folds, n_jobs=-1, refit=False)
    gs.fit(X_dev[feats], y_dev)
    return gs.best_params_, gs.best_score_

results = []
for name in SEARCH:
    for drop_m12 in (False, True):
        for feat_set, feats in (('all', FEATURES), ('no country', NO_COUNTRY)):
            params, score = search(name, drop_m12, feats)
            results.append(dict(model=name, train_M12='dropped' if drop_m12 else 'kept', features=feat_set,
                                cv_PR_AUC=score, params=params))
res = pd.DataFrame(results)
res.pivot_table(index='model', columns=['train_M12', 'features'], values='cv_PR_AUC').round(3)
""")

md(r"""
- **Dropping the M12 cohort from training helps every model** — the event-driven cohort teaches the wrong base rate and wrong patterns.
- Country features: small / inconsistent effect → we keep the simpler, more shift-robust variant when scores tie (see below).
- Selected configuration per model (best CV PR-AUC):
""", slide='subslide')

code(r"""
best = res.sort_values('cv_PR_AUC', ascending=False).groupby('model').head(1).set_index('model')
for name, p in best.params.items():
    print(f'{name:>12}: ' + ', '.join(f"{k.split('__')[-1]}={v}" for k, v in p.items()))
best[['train_M12', 'features', 'cv_PR_AUC']].round(3)
""")

md(r"""
## 5.1 Threshold selection and final evaluation on the hold-out cohort (M3)

For each tuned model: out-of-fold probabilities on the inner folds → pick the threshold maximising F1 →
refit on all development cohorts → score M3 once.
""")

code(r"""
def f1_threshold(y_true, p):
    grid = np.arange(0.05, 0.96, 0.01)
    return grid[np.argmax([f1_score(y_true, p >= t) for t in grid])]

def build(name, params):
    return clone(SEARCH[name][0]).set_params(**params)

final, probs = [], {}
for name, row in best.iterrows():
    feats = FEATURES if row.features == 'all' else NO_COUNTRY
    excl = (1,) if row.train_M12 == 'dropped' else ()
    oof_y, oof_p = [], []
    for tr, va in forward_folds(coh_dev, exclude=excl):
        m = build(name, row.params).fit(X_dev.iloc[tr][feats], y_dev.iloc[tr])
        oof_y.append(y_dev.iloc[va]); oof_p.append(m.predict_proba(X_dev.iloc[va][feats])[:, 1])
    thr = f1_threshold(np.concatenate(oof_y), np.concatenate(oof_p))
    keep = ~np.isin(coh_dev, excl)
    model = build(name, row.params).fit(X_dev[keep][feats], y_dev[keep])
    p = model.predict_proba(X_hold[feats])[:, 1]; probs[name] = p
    final.append(dict(model=name, threshold=thr, F1=f1_score(y_hold, p >= thr), precision=precision_score(y_hold, p >= thr),
                      recall=recall_score(y_hold, p >= thr), PR_AUC=average_precision_score(y_hold, p), ROC_AUC=roc_auc_score(y_hold, p)))
    best.loc[name, 'threshold'] = thr

# heuristic baseline: active on >= k days, k tuned on the same inner folds
oof = np.concatenate([va for _, va in forward_folds(coh_dev, exclude=(1,))])
k = max(range(1, 10), key=lambda k: f1_score(y_dev.iloc[oof], X_dev.n_active_days.iloc[oof] >= k))
pb = (X_hold.n_active_days >= k).astype(int)
final.append(dict(model=f'Baseline (active days >= {k})', threshold=np.nan, F1=f1_score(y_hold, pb), precision=precision_score(y_hold, pb),
                  recall=recall_score(y_hold, pb), PR_AUC=np.nan, ROC_AUC=np.nan))
final.append(dict(model='Predict everyone active', threshold=np.nan, F1=f1_score(y_hold, np.ones_like(y_hold)),
                  precision=y_hold.mean(), recall=1.0, PR_AUC=y_hold.mean(), ROC_AUC=0.5))
final = pd.DataFrame(final).set_index('model')
final.round(3)
""")

md(r"""
- **Final model = GradBoost** (highest CV PR-AUC 0.508, trained without M12, without country features). On the hold-out
  cohort it reaches **F1 = 0.47** (precision 0.45, recall 0.49, ROC-AUC 0.83).
- All three ML models are within ~0.02 F1 of each other on M3 (LogReg is marginally higher, 0.48) — differences of that size
  are within the noise of a 243-positive test cohort, so we keep the CV-selected model rather than cherry-picking on the hold-out.
- Every ML model beats the product rule-of-thumb (**+0.11 F1**) and the trivial "everyone active" rule (**+0.25 F1**).
""", slide='fragment')

code(r"""
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2))
plot_df = final.drop(columns=['threshold', 'ROC_AUC']).reset_index().melt(id_vars='model', var_name='metric')
sns.barplot(data=plot_df, x='value', y='model', hue='metric', ax=axes[0])
axes[0].set(title='Hold-out cohort M3', xlabel='', ylabel=''); axes[0].legend(loc='upper center', bbox_to_anchor=(0.5, -0.08), ncol=4, fontsize=8)
for name, p in probs.items():
    pr, rc, _ = precision_recall_curve(y_hold, p)
    axes[1].plot(rc, pr, label=f'{name} (AP={average_precision_score(y_hold, p):.2f})')
axes[1].axhline(y_hold.mean(), ls='--', c='grey', label=f'no-skill ({y_hold.mean():.2f})')
axes[1].set(xlabel='recall', ylabel='precision', title='Precision–recall curves (M3)'); axes[1].legend(fontsize=8)
plt.tight_layout(); plt.show()
""", slide='subslide')

md(r"""
## 5.2 What drives the best model?
""")

code(r"""
BEST = best.cv_PR_AUC.idxmax()          # chosen on CV only — the hold-out is never used for selection
row = best.loc[BEST]; feats = FEATURES if row.features == 'all' else NO_COUNTRY
excl = (1,) if row.train_M12 == 'dropped' else ()
best_model = build(BEST, row.params).fit(X_dev[~np.isin(coh_dev, excl)][feats], y_dev[~np.isin(coh_dev, excl)])
pi = permutation_importance(best_model, X_hold[feats], y_hold, scoring='average_precision', n_repeats=10, random_state=RNG, n_jobs=-1)
imp = pd.Series(pi.importances_mean, feats).sort_values(ascending=False).head(12)

p_best = probs[BEST]; thr = best.loc[BEST, 'threshold']
fig, axes = plt.subplots(1, 2, figsize=(13, 4.2), gridspec_kw={'width_ratios': [1.6, 1]})
sns.barplot(x=imp.values, y=imp.index, ax=axes[0], color='C0')
axes[0].set(title=f'{BEST}: permutation importance on M3 (Δ PR-AUC)', xlabel='drop in PR-AUC when shuffled')
cm = confusion_matrix(y_hold, p_best >= thr)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False, ax=axes[1],
            xticklabels=['pred inactive', 'pred active'], yticklabels=['inactive', 'active'])
axes[1].set(title=f'Confusion matrix (threshold {thr:.2f})'); plt.tight_layout(); plt.show()
""")

md(r"""
- **Recency** (`days_since_last`) is by far the most important signal, followed by **regularity** (`active_day_ratio`,
  `n_active_days`) and *doing* signals (successful-submission bucket, competitions joined, submissions, hackathon participation).
- Profile variables contribute little (only the masked `FeatureX` appears in the top 12; country was dropped by the search) —
  engagement is about **behaviour, not demographics**, which is good for fairness and actionability.
- At the F1-optimal threshold the model finds about half of the returning users with ~45 % precision ($\approx$ 3.7× the 12 % base rate).
""")

# =====================================================================
md(r"""
## 6. Real-world impact — who should Zindi target?

A retention campaign has a budget: contact the top-*x* % of users ranked by the model.
""")

code(r"""
order = np.argsort(-p_best)
cum_pos = np.cumsum(y_hold.values[order]) / y_hold.sum()
share = np.arange(1, len(order) + 1) / len(order)
fig, axes = plt.subplots(1, 2, figsize=(13, 4))
axes[0].plot(share, cum_pos, label=BEST); axes[0].plot([0, 1], [0, 1], '--', c='grey', label='random')
axes[0].set(xlabel='share of cohort contacted (ranked by model)', ylabel='share of returning users captured', title='Cumulative gains (M3)')
axes[0].legend()
dec = pd.qcut(pd.Series(p_best).rank(method='first'), 10, labels=range(10, 0, -1))
lift = pd.Series(y_hold.values).groupby(dec).mean().sort_index() / y_hold.mean()
sns.barplot(x=lift.index.astype(int), y=lift.values, ax=axes[1], color='C2', order=range(1, 11))
axes[1].axhline(1, ls='--', c='grey'); axes[1].set(xlabel='decile (1 = highest predicted probability)', ylabel='lift vs. average', title='Lift by decile')
plt.tight_layout(); plt.show()
top20 = cum_pos[int(.2 * len(order)) - 1]
bottom50 = 1 - cum_pos[int(.5 * len(order)) - 1]
print(f'Top 20 % by score contain {top20:.0%} of all returning users;  bottom 50 % contain only {bottom50:.0%}.')
""")

md(r"""
**Reading the curves**: the top decile is **4×** more likely to return than average; the top 20 % of users by score contain
**63 %** of all returners, while the bottom half contains only **13 %**.

**Illustrative business case** (assumptions stated explicitly — to be replaced by Zindi's real numbers):

- *Churn-prevention campaign*: the model's **bottom half** holds very few returners, so Zindi can
  concentrate a costly personal intervention (mentor call, tailored beginner competition) on the **middle deciles** —
  users with some engagement but uncertain outcome — instead of the whole cohort.
- *Community / recruiting*: the **top decile** is several times more likely to be active than average → the natural
  shortlist for hackathon invitations and ambassador programmes.
- Example: 2 000 sign-ups/month, intervention cost 5 USD/user. Contacting everybody = 10 000 USD. Contacting the 40 % "uncertain"
  segment = 4 000 USD (−60 %) while still covering the users whose behaviour can plausibly be changed.
- The *causal* effect of an intervention cannot be estimated from these observational data → an **A/B test**
  (random hold-out within the targeted segment) is required before claiming revenue impact.
""")

md(r"""
## 6.1 Predictions for the official test cohort (M4)
""")

code(r"""
keep = ~np.isin(coh, excl)                             # final model: all labelled cohorts except excluded ones
final_model = build(BEST, row.params).fit(X[keep][feats], y[keep])
p_test = final_model.predict_proba(X_test[feats])[:, 1]
sub = pd.DataFrame({'User_ID_Next_month_Activity': X_test.index + '_Month_5', 'Active': (p_test >= thr).astype(int)})
sub = sample_sub[['User_ID_Next_month_Activity']].merge(sub, how='left').fillna({'Active': 0}).astype({'Active': int})
sub.to_csv('submission.csv', index=False)
print(f'{len(sub)} rows written to submission.csv; predicted active share = {sub.Active.mean():.3f}')
print(f'(M4 activity log ends on day {act[act.t == TEST_COHORT].day.max()} — late sign-ups have truncated features)')
sub.head()
""")

# =====================================================================
md(r"""
## 7. Conclusions

**Findings**
- The labelled training set had to be *reconstructed*: we de-anonymised the month order from the data itself and derived the target.
- **Recency and regularity of first-month activity** predict month-2 retention far better than demographics; *doing* (submitting, downloading data, joining) beats *browsing*.
- Retention is **non-stationary**: one hackathon made a cohort's retention jump from ~15 % to 78 %; the sign-up form change
  made `country` missing for most later users. Both would silently break a naïvely validated model.

**ML experiment critique**
- Random K-fold would have overstated performance by ~2×; forward-chaining CV is the honest estimate.
- Excluding the event-driven cohort from training was the single most useful "data" decision; model choice mattered less than validation design.
- Limits: only 5 labelled cohorts (small, noisy fold estimates); masked features; M4 log truncated at day 22;
  retention of event cohorts is driven by an *external calendar* (hackathons) that the features only partially capture.

**Did we solve the problem?** Largely for *ranking*, partly for *exact classification*. On an unseen future cohort the
model reaches F1 = 0.47 vs 0.36 for the best rule of thumb, and concentrates 63 % of returners in the top 20 % of users — enough to
make targeted retention/community programmes several times cheaper than blanket campaigns. Absolute F1 stays moderate
because many returns are triggered by future events (new competitions, hackathons) that are invisible in month 1.

**Next steps**: add the platform's competition calendar (upcoming launches) as features; train on more cohorts;
calibrate probabilities per cohort; validate business impact with an A/B-tested retention campaign.
""")

nb = nbf.v4.new_notebook(cells=cells)
nb.metadata['kernelspec'] = {'name': 'python3', 'display_name': 'Python 3', 'language': 'python'}
nb.metadata['celltoolbar'] = 'Slideshow'
nb.metadata['title'] = 'Predicting New-User Engagement on Zindi'
nbf.write(nb, 'zindi_engagement.ipynb')
print('written', len(cells), 'cells')
