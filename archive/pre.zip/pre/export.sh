#!/bin/bash
# Execute the notebook and export reveal.js slides + PDF (helper cells tagged hide_input show outputs only).
set -e
cd "$(dirname "$0")"
NB=zindi_engagement
HIDE="--TagRemovePreprocessor.remove_input_tags=hide_input"
python build_notebook.py
jupyter nbconvert --to notebook --execute --inplace --ExecutePreprocessor.timeout=1800 $NB.ipynb
jupyter nbconvert --to slides $NB.ipynb $HIDE --SlidesExporter.reveal_scroll=True

# PDF: wrap long code/output lines and use slightly smaller margins
TMP=$(mktemp -d)
jupyter nbconvert --to latex $NB.ipynb $HIDE --output-dir $TMP
sed -i 's/\\geometry{verbose,tmargin=1in,bmargin=1in,lmargin=1in,rmargin=1in}/\\geometry{verbose,tmargin=0.8in,bmargin=0.8in,lmargin=0.75in,rmargin=0.75in}\n    \\usepackage{fvextra}\\fvset{breaklines=true,breakanywhere=true,fontsize=\\small}\n    \\setcounter{secnumdepth}{0}/' $TMP/$NB.tex
(cd $TMP && xelatex -interaction=nonstopmode $NB.tex >/dev/null && xelatex -interaction=nonstopmode $NB.tex >/dev/null) || true
grep -i "missing character" $TMP/$NB.log || true
cp $TMP/$NB.pdf .
grep -c "Overfull" $TMP/$NB.log || true
grep "^!" $TMP/$NB.log || true
rm -rf "${TMP:?}"
ls -la $NB.*
