"""Builds ../zindi_engagement_slides.pptx (native PowerPoint charts, light theme).

Run from pre/:  python slides/build_pptx.py
Needs python-pptx. Results come from slides/nb_results.pkl; if it is missing, the
notebook's code cells are re-executed to recreate it (~1-2 min).
"""
import json, pathlib, pickle
import numpy as np, pandas as pd
from matplotlib import cm
from pptx import Presentation
from pptx.chart.data import CategoryChartData, XyChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_TICK_LABEL_POSITION, XL_TICK_MARK, XL_MARKER_STYLE
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

HERE = pathlib.Path(__file__).resolve().parent
PRE = HERE.parent
CACHE = HERE / 'nb_results.pkl'
OUT = PRE / 'zindi_engagement_slides.pptx'


# ---------------------------------------------------------------- results
def load_results():
    if CACHE.exists():
        return pickle.load(open(CACHE, 'rb'))
    import os, matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.show = lambda *a, **k: plt.close('all')
    os.chdir(PRE)
    ns = {}
    for c in json.load(open(PRE / 'zindi_engagement.ipynb'))['cells']:
        if c['cell_type'] == 'code':
            exec(''.join(c['source']).replace("pd.set_option('display.latex.repr', True)", ''), ns)
    d = dict(ct=ns['ct'], lab_rates=ns['lab'].groupby('cohort').Active.mean().rename(index=ns['LABEL']),
             dau=ns['dau'], normal=ns['normal'][['n_active_days', 'days_since_last', 'Active'] + ns['beh']],
             rates=ns['rates'], miss=ns['miss'], res=ns['res'], final=ns['final'], probs=ns['probs'],
             y_hold=ns['y_hold'], imp=ns['imp'], cm=ns['cm'], thr=ns['thr'], BEST=ns['BEST'],
             cum_pos=ns['cum_pos'], share=ns['share'], lift=ns['lift'], sub=ns['sub'])
    pickle.dump(d, open(CACHE, 'wb'))
    return d


D = load_results()

# ---------------------------------------------------------------- style
INK, MUTED, SUB = '1B2433', '4F5868', '6B7280'
BLUE, BLUE_DK, BLUE_TINT, BLUE_LT = '2F5FD0', '1F3F8F', 'EEF2FA', 'C9D6F2'
ORANGE, ORANGE_DK, ORANGE_TINT = 'D9691F', 'B4530F', 'FBEDE3'
GREY, CARD, LINE, WHITE = 'AEB6C1', 'F4F5F7', 'DDE2E8', 'FFFFFF'
FONT, MONO = 'Calibri', 'Courier New'
W, H, L = 13.333, 7.5, 0.6          # slide size and side margin (inches)
CW = W - 2 * L                       # content width

rgb = RGBColor.from_string
prs = Presentation()
prs.slide_width, prs.slide_height = Inches(W), Inches(H)
BLANK = prs.slide_layouts[6]
page = [0]


def text(slide, x, y, w, h, paras, size=16, color=INK, bold=False, align=PP_ALIGN.LEFT,
         anchor=MSO_ANCHOR.TOP, font=FONT, spacing=None, margin=0):
    """paras: str | list of paragraphs; a paragraph is str or list of (text, {bold,color,size,italic}) runs."""
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = Inches(margin)
    for i, para in enumerate([paras] if isinstance(paras, str) else paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align
        if spacing:
            p.space_after = Pt(spacing)
        for run_text, fmt in ([(para, {})] if isinstance(para, str) else para):
            r = p.add_run()
            r.text = run_text
            f = r.font
            f.name = fmt.get('font', font)
            f.size = Pt(fmt.get('size', size))
            f.bold = fmt.get('bold', bold)
            f.italic = fmt.get('italic', False)
            f.color.rgb = rgb(fmt.get('color', color))
    return tb


def box(slide, x, y, w, h, fill=CARD, line=None, shape=MSO_SHAPE.ROUNDED_RECTANGLE, radius=0.06, dash=False):
    s = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    if fill:
        s.fill.solid(); s.fill.fore_color.rgb = rgb(fill)
    else:
        s.fill.background()
    if line:
        s.line.color.rgb = rgb(line); s.line.width = Pt(1.25)
        if dash:
            from pptx.enum.dml import MSO_LINE_DASH_STYLE
            s.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    else:
        s.line.fill.background()
    s.shadow.inherit = False
    if shape == MSO_SHAPE.ROUNDED_RECTANGLE:
        s.adjustments[0] = radius
    return s


def label_box(slide, x, y, w, h, label, fill, color, bold=False, size=15, line=None, dash=False):
    s = box(slide, x, y, w, h, fill=fill, line=line, dash=dash, radius=0.15)
    tf = s.text_frame
    tf.margin_left = tf.margin_right = Inches(0.05)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = label
    r.font.name, r.font.size, r.font.bold, r.font.color.rgb = FONT, Pt(size), bold, rgb(color)
    return s


def dot(slide, x, y, d, label, fill=BLUE, color=WHITE, size=16):
    s = slide.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(d), Inches(d))
    s.fill.solid(); s.fill.fore_color.rgb = rgb(fill); s.line.fill.background(); s.shadow.inherit = False
    tf = s.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = label
    r.font.name, r.font.size, r.font.bold, r.font.color.rgb = FONT, Pt(size), True, rgb(color)


def new_slide(eyebrow, title, notes, footnote=None):
    page[0] += 1
    s = prs.slides.add_slide(BLANK)
    s.background.fill.solid(); s.background.fill.fore_color.rgb = rgb(WHITE)
    if eyebrow:
        text(s, L, 0.42, CW, 0.3, [[(eyebrow.upper(), {})]], size=12, color=BLUE, bold=True)
        text(s, L, 0.7, CW, 0.75, title, size=32, bold=True)
        foot = 'Zindi new-user engagement' + (f'  ·  {footnote}' if footnote else '')
        text(s, L, 7.0, 10, 0.3, foot, size=10, color=SUB)
        text(s, W - L - 1, 7.0, 1, 0.3, f'{page[0]:02d}', size=10, color=SUB, align=PP_ALIGN.RIGHT)
    s.notes_slide.notes_text_frame.text = notes
    return s


def caption(slide, x, y, w, t):
    text(slide, x, y, w, 0.3, t, size=13, color=MUTED)


def table(slide, x, y, w, rows, col_w, size=14, row_h=0.42, align=None, fills=None, colors=None, bold_rows=()):
    nr, nc = len(rows), len(rows[0])
    gt = slide.shapes.add_table(nr, nc, Inches(x), Inches(y), Inches(w), Inches(row_h * nr)).table
    for j, cw in enumerate(col_w):
        gt.columns[j].width = Inches(w * cw)
    for i, row in enumerate(rows):
        gt.rows[i].height = Inches(row_h)
        for j, val in enumerate(row):
            c = gt.cell(i, j)
            c.fill.solid()
            c.fill.fore_color.rgb = rgb('E4E9F0' if i == 0 else (fills or {}).get(i, WHITE if i % 2 else 'F8F9FB'))
            c.margin_left = c.margin_right = Inches(0.12)
            c.margin_top = c.margin_bottom = Inches(0.05)
            c.vertical_anchor = MSO_ANCHOR.MIDDLE
            tf = c.text_frame; tf.word_wrap = True
            p = tf.paragraphs[0]
            p.alignment = (align or [PP_ALIGN.LEFT] * nc)[j]
            r = p.add_run(); r.text = str(val)
            r.font.name, r.font.size = FONT, Pt(size)
            r.font.bold = i == 0 or i in bold_rows
            r.font.color.rgb = rgb((colors or {}).get((i, j), INK))
    return gt


def style_chart(chart, size=13, legend=False):
    chart.font.name, chart.font.size = FONT, Pt(size)
    chart.font.color.rgb = rgb(MUTED)
    chart.has_title = False
    chart.has_legend = legend
    if legend:
        chart.legend.position = XL_LEGEND_POSITION.TOP
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(size)


def quiet_axes(chart, show_values=False, gridlines=False, cat_title=None, val_title=None, val_fmt=None):
    ca, va = chart.category_axis, chart.value_axis
    ca.format.line.color.rgb = rgb(LINE)
    ca.has_major_gridlines = False
    ca.major_tick_mark = va.major_tick_mark = XL_TICK_MARK.NONE
    va.has_major_gridlines = gridlines
    if gridlines:
        va.major_gridlines.format.line.color.rgb = rgb('E6E9EE')
    va.format.line.fill.background()
    if not show_values:
        va.tick_label_position = XL_TICK_LABEL_POSITION.NONE
    if val_fmt:
        va.tick_labels.number_format, va.tick_labels.number_format_is_linked = val_fmt, False
    for ax, t in ((ca, cat_title), (va, val_title)):
        if t:
            ax.has_title = True
            ax.axis_title.text_frame.text = t
            f = ax.axis_title.text_frame.paragraphs[0].runs[0].font
            f.size, f.bold, f.color.rgb, f.name = Pt(12), False, rgb(MUTED), FONT


def bar_chart(slide, x, y, w, h, cats, vals, colors, fmt='0%', horizontal=False, label_size=14,
              cat_title=None, gap=60, val_max=None, label_color=INK):
    cd = CategoryChartData(); cd.categories = cats
    cd.add_series('s', list(vals))
    kind = XL_CHART_TYPE.BAR_CLUSTERED if horizontal else XL_CHART_TYPE.COLUMN_CLUSTERED
    ch = slide.shapes.add_chart(kind, Inches(x), Inches(y), Inches(w), Inches(h), cd).chart
    style_chart(ch)
    plot = ch.plots[0]; plot.gap_width = gap; plot.vary_by_categories = False
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.number_format, dl.number_format_is_linked = fmt, False
    dl.position = XL_LABEL_POSITION.OUTSIDE_END
    dl.font.size, dl.font.bold, dl.font.color.rgb = Pt(label_size), True, rgb(label_color)
    for i, c in enumerate(colors):
        pt = plot.series[0].points[i]
        pt.format.fill.solid(); pt.format.fill.fore_color.rgb = rgb(c)
    quiet_axes(ch, cat_title=cat_title)
    va = ch.value_axis
    va.minimum_scale = 0
    if val_max:
        va.maximum_scale = val_max
    return ch


def point_label(pt, label, size=12, color=INK, pos=XL_LABEL_POSITION.RIGHT):
    dl = pt.data_label
    dl.has_text_frame = True
    dl.text_frame.text = label
    dl.position = pos
    for r in dl.text_frame.paragraphs[0].runs:
        r.font.size, r.font.bold, r.font.name, r.font.color.rgb = Pt(size), True, FONT, rgb(color)


def skip_labels(axis, n):
    from pptx.oxml.ns import qn
    ax = axis._element
    for tag in ('c:tickLblSkip', 'c:tickMarkSkip'):
        old = ax.find(qn(tag))
        if old is not None:
            ax.remove(old)
    el = ax.makeelement(qn('c:tickLblSkip'), {'val': str(n)})
    # schema order: tickLblSkip comes after c:lblOffset / c:lblAlgn / c:auto ... noMultiLvlLbl is last
    nm = ax.find(qn('c:noMultiLvlLbl'))
    (nm.addprevious(el) if nm is not None else ax.append(el))


def blues(n):
    return ['%02X%02X%02X' % tuple(int(255 * v) for v in cm.Blues(t)[:3]) for t in np.linspace(0.35, 0.85, n)]


# ================================================================ 1. cover
s = new_slide(None, None, "Introduce the team and the question: at the end of a new user's first month on Zindi, "
              "can we predict whether they will come back in month two? The talk follows the grading rubric: problem "
              "and data, preparation and EDA, validation and models, results and impact.")
s.background.fill.fore_color.rgb = rgb('F5F7FB')
text(s, L, 1.3, 7.2, 0.35, [[('ML WITH PYTHON  ·  FINAL PROJECT', {})]], size=13, color=BLUE, bold=True)
text(s, L, 1.75, 7.2, 1.9, 'Predicting new-user engagement on Zindi', size=44, bold=True)
text(s, L, 3.75, 6.8, 0.9, 'Will a user who just signed up still be active in their second month?', size=20, color=MUTED)
text(s, L, 5.6, 6.5, 0.8, [[('[Team name]', {'bold': True})], [('[Member 1]  ·  [Member 2]  ·  [Member 3]', {'color': MUTED})]], size=16, spacing=4)
text(s, L, 6.55, 7, 0.35, 'Data: Zindi New User Engagement Prediction Challenge (2022–23)', size=11, color=SUB)
px, pw = 8.35, 4.38
box(s, px, 1.3, pw, 5.25, fill=WHITE, line=LINE)
text(s, px + 0.4, 1.55, pw - 0.8, 0.35, [[('RESULTS AT A GLANCE', {})]], size=11, color=SUB, bold=True)
for k, (big, small) in enumerate([('F1 = 0.47', 'on an unseen future cohort (rule of thumb: 0.36)'),
                                  ('63%', 'of returning users found in the top 20% of scores'),
                                  ('~60%', 'lower campaign cost with targeted outreach')]):
    yy = 2.0 + k * 1.45
    text(s, px + 0.4, yy, pw - 0.8, 0.65, big, size=34, bold=True, color=BLUE)
    text(s, px + 0.4, yy + 0.62, pw - 0.8, 0.6, small, size=13, color=MUTED)

# ================================================================ 2. problem
s = new_slide('1 · Problem', 'Most new users never come back',
              "Zindi is Africa's largest data-science competition platform. Most sign-ups are one-month tourists: only "
              "12 to 21 percent of a typical cohort comes back in month two. Our task: at the end of the sign-up month, "
              "predict whether the user does anything next month. That is binary classification, scored with F1 on the "
              "positive class.")
text(s, L, 2.2, 5.2, 1.3, '12–21%', size=88, bold=True, color=BLUE)
text(s, L, 3.6, 4.8, 0.9, 'of a typical monthly sign-up cohort is active again in its second month', size=18, color=MUTED)
box(s, 6.3, 1.75, 6.43, 4.5, fill=BLUE_TINT)
text(s, 6.75, 2.15, 5.6, 0.5, 'The task', size=24, bold=True)
text(s, 6.75, 2.8, 5.6, 1.6, [[("At the end of a user's ", {}), ('sign-up month', {'bold': True}),
                               (', predict whether they will do ', {}), ('anything', {'bold': True}),
                               (' on Zindi in the next month: view a page, join a competition, submit, post.', {})]], size=18)
for k, chip in enumerate(['Binary classification', 'Metric: F1 on the positive class', '≈ 12.4k sign-ups in 7 months']):
    label_box(s, 6.75, 4.45 + k * 0.55, 3.6, 0.42, chip, WHITE, BLUE_DK, size=14)

# ================================================================ 3. value
s = new_slide('1 · Why it matters', 'Early warning, while users are still reachable',
              "A user who survives month two is far more likely to become a long-term member, competitor and potential "
              "hire. The model helps in three ways: target retention spend at users at risk, find likely-engaged "
              "newcomers early, and show which behaviours drive retention.")
cards = [('Targeted retention', 'Send onboarding nudges, beginner competitions or mentoring to users at risk, instead of '
          'mailing everyone. Lower cost, less unsubscribe fatigue.'),
         ('Find future members', "Shortlist likely-engaged newcomers for hackathons, ambassador programmes and Zindi's "
          'hiring clients.'),
         ('Product insight', 'Learn which first-month behaviours drive retention, for example submitting versus only '
          'browsing.')]
cwid = (CW - 0.6) / 3
for k, (h3, body) in enumerate(cards):
    cx = L + k * (cwid + 0.3)
    box(s, cx, 1.75, cwid, 3.35, fill=CARD)
    dot(s, cx + 0.35, 2.1, 0.55, str(k + 1))
    text(s, cx + 0.35, 2.85, cwid - 0.7, 0.5, h3, size=20, bold=True)
    text(s, cx + 0.35, 3.4, cwid - 0.7, 1.6, body, size=15, color=MUTED)
box(s, L, 5.45, CW, 0.95, fill=BLUE_TINT)
text(s, L + 0.35, 5.45, CW - 0.7, 0.95, [[('Acquisition is expensive and churn is fast: Zindi has to know ', {}),
                                          ('at the end of month one', {'bold': True}), (' who is about to drop out.', {})]],
     size=18, anchor=MSO_ANCHOR.MIDDLE)

# ================================================================ 4. data
s = new_slide('1 · Data', 'Eight relational tables, with dates masked',
              "Eight tables linked by user ID and competition ID; the activity log has over 300 thousand events. Dates "
              "are masked: year and month are recoded, so before modelling we first had to work out the order of the months.")
rows = [['Table', 'Rows', 'Holds'],
        ['Users', '12,413', 'sign-up date, country, 2 masked profile features'],
        ['UserActivity', '317,292', 'page views and clicks, 70+ event titles'],
        ['CompetitionParticipation', '8,385', 'enrolments, submission bucket'],
        ['Discussion · Comments', '1,906', 'forum posts (1,439 + 467)'],
        ['Competition', '247', 'metadata; secret code = hackathon'],
        ['Blogs · Jobs', '–', 'content only, no user link: not used']]
table(s, L, 1.75, 7.9, rows, [0.33, 0.14, 0.53], size=14, row_h=0.55, align=[PP_ALIGN.LEFT, PP_ALIGN.RIGHT, PP_ALIGN.LEFT])
box(s, 8.9, 1.75, 3.83, 3.85, fill=ORANGE_TINT)
dot(s, 9.25, 2.1, 0.55, '?', fill=ORANGE_DK)
text(s, 9.25, 2.85, 3.2, 0.45, 'Masked time', size=20, bold=True)
text(s, 9.25, 3.35, 3.2, 2.2, ['Year and month are recoded. Months are in order, but month 1 is not January.',
                               'Only day of month and time of day are real.'], size=15, color=MUTED, spacing=8)
text(s, L, 6.0, 7.9, 0.4, [[('Loaded with ', {}), ('pandas.read_csv', {'font': MONO, 'color': BLUE_DK}),
                            (', joined on User_ID and Competition ID.', {})]], size=15, color=MUTED)

# ================================================================ 5. timeline (heatmap table)
s = new_slide('1 · Data', 'The data reveals its own timeline',
              "We cross-tabulated sign-up month against activity month. Users can only be active after they register, "
              "so the zeros below the diagonal reveal the order: M11, M12, then M1 to M5. The M4 cohort has essentially "
              "no activity in M5 because Zindi removed it: that cohort is the hidden test set, so we build our own labels.")
ct = D['ct']
caption(s, L, 1.6, 7.5, 'Events by sign-up cohort (rows) × activity month (columns)')
hx, hy, cwh, rh = L, 2.0, 1.0, 0.56
n = ct.shape[0]
gt = s.shapes.add_table(n + 1, n + 1, Inches(hx), Inches(hy), Inches(cwh * (n + 1)), Inches(rh * (n + 1))).table
v = np.log10(ct.values + 1); vmax = v.max()
for i in range(n + 1):
    gt.rows[i].height = Inches(rh)
    gt.columns[i].width = Inches(cwh if i else 0.75)
    for j in range(n + 1):
        c = gt.cell(i, j); c.margin_left = c.margin_right = Inches(0.03)
        c.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = c.text_frame.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        r = p.add_run(); r.font.name = FONT; r.font.size = Pt(12)
        c.fill.solid()
        if i == 0 or j == 0:
            c.fill.fore_color.rgb = rgb(WHITE)
            r.text = '' if i == j == 0 else (ct.columns[j - 1] if i == 0 else ct.index[i - 1])
            r.font.bold, r.font.color.rgb = True, rgb(MUTED)
        else:
            val, t = ct.values[i - 1, j - 1], v[i - 1, j - 1] / vmax
            c.fill.fore_color.rgb = rgb('%02X%02X%02X' % tuple(int(255 * q) for q in cm.Blues(0.04 + 0.9 * t)[:3]))
            r.text = f'{val:,}'
            r.font.color.rgb = rgb(WHITE if t > 0.62 else (GREY if val == 0 else INK))
pts = [('Users act only after they register, so the near-triangular shape gives the order ',
        'M11 → M12 → M1 → … → M5.'),
       ('The M4 cohort has almost no M5 activity (8 of 1,382 users): Zindi hid it. ', 'It is the test set.'),
       ('So we ', 'build the labels ourselves from cohorts M11 to M3.')]
for k, (a, b) in enumerate(pts):
    yy = 2.0 + k * 1.45
    dot(s, 9.15, yy, 0.5, str(k + 1))
    text(s, 9.85, yy - 0.03, 2.9, 1.3, [[(a, {}), (b, {'bold': True})]], size=15)

# ================================================================ 6. target and X / y
s = new_slide('1 · Target and X / y', 'Target: active in the month after sign-up',
              "The target is one if the user appears in any of the four event tables in the month after sign-up. "
              "Features only use the sign-up month, which is what Zindi knows when it has to act. X has 9,026 labelled "
              "users and 50 features. Note the M12 cohort with 78 percent: we come back to it in the EDA.")
text(s, L, 1.7, 7.2, 1.1, [[('Active = 1', {'bold': True}), (' if the user has any record (activity, enrolment, discussion '
                            'or comment) in the month right after sign-up. Features use the ', {}),
                            ('sign-up month only', {'bold': True}), (', so nothing leaks from the future.', {})]], size=16)
box(s, L, 3.0, 7.2, 2.85, fill=CARD, radius=0.04)
code = ["events = pd.concat([act, part, disc, com])",
        "active_next = ev.loc[ev.t == ev.cohort + 1, 'User_ID']",
        "users['Active'] = users.User_ID.isin(active_next)", "",
        "X, y = lab[FEATURES], lab['Active']",
        "# X: (9026, 50)   y: 30.5 % positive",
        "X_test = df.loc[df.cohort == M4, FEATURES]",
        "# (1382, 50): label hidden by Zindi"]
text(s, L + 0.3, 3.25, 6.7, 2.5, [[(ln, {'color': BLUE if ln.startswith('#') else INK})] for ln in code],
     size=13, font=MONO, spacing=3)
rows = [['Cohort', 'Users', 'Active in m+1'], ['M11', '1,262', '19.8%'], ['M12', '1,982', '78.4%'],
        ['M1', '1,504', '20.7%'], ['M2', '2,278', '17.5%'], ['M3', '2,000', '12.2%'], ['M4', '1,382', 'test set']]
table(s, 8.3, 1.7, 4.43, rows, [0.3, 0.3, 0.4], size=15, row_h=0.55,
      align=[PP_ALIGN.LEFT, PP_ALIGN.RIGHT, PP_ALIGN.RIGHT], fills={2: ORANGE_TINT, 6: BLUE_TINT},
      colors={(2, 2): ORANGE_DK, (6, 2): BLUE_DK}, bold_rows=(2,))

# ================================================================ 7. preparation
s = new_slide('2 · Data preparation', 'Every transformation has a reason',
              "Each row is one transformation and why we did it. The key one: we only aggregate events from the sign-up "
              "month, so no future information leaks into the features. Missing country gets its own category plus a "
              "flag, because the missingness itself carries information. Month lengths are masked too, so each exposure "
              "window ends at the last logged day of that month; the M4 log stops at day 22.")
rows = [['Issue', 'What we do', 'Why'],
        ['Long, multi-table event logs', 'Aggregate per user, sign-up month only', 'One row per user; no look-ahead leakage'],
        ['70+ raw event titles', 'Group into 18 behaviour families', 'IDs are sparse; behaviour type generalises'],
        ['Country missing for 47%', '"Missing" category + binary flag', 'Missingness is informative; no invented data'],
        ['146 masked countries', 'Top 10 + "Other", one-hot', 'Enough users per level; less overfitting'],
        ['FeatureY in {0, 1, 3}', 'One-hot', 'Codes are nominal, not ordinal'],
        ['Submissions as "count 10", NaN', 'Parse the number; NaN → 0', 'NaN means no successful submission'],
        ['Late sign-ups see fewer days', 'days_observed, active_day_ratio, days_since_last', 'Normalises activity by exposure']]
table(s, L, 1.7, CW, rows, [0.28, 0.37, 0.35], size=15, row_h=0.6)

# ================================================================ 8. features
s = new_slide('2 · Feature engineering', '50 features, all from the sign-up month',
              "Six feature groups, all computed from the sign-up month. Two were motivated directly by the EDA: joined a "
              "hackathon, and the number of newly launched competitions joined, since a fresh competition is likely still "
              "running next month. The new-competition flag only uses past and present logs, so it does not leak.")
groups = [('Volume and regularity', 'events, active days, distinct actions, active-day ratio', BLUE),
          ('Recency', 'days since last activity at month end: fresh activity tends to continue', BLUE),
          ('Behaviour mix', 'counts for 18 families: submit, download data, learning pages, jobs …', BLUE),
          ('Competition context', 'competitions joined, submission bucket, new competitions joined, joined a hackathon', ORANGE_DK),
          ('Community', 'discussions started, comments written', ORANGE_DK),
          ('Profile and timing', 'FeatureX / Y, country + missing flag, sign-up day and hour, days observed', SUB)]
gw, gh = (CW - 0.6) / 3, 2.15
for k, (h3, body, col) in enumerate(groups):
    gx, gy = L + (k % 3) * (gw + 0.3), 1.75 + (k // 3) * (gh + 0.3)
    box(s, gx, gy, gw, gh, fill=CARD)
    dot(s, gx + 0.35, gy + 0.35, 0.22, '', fill=col)
    text(s, gx + 0.7, gy + 0.25, gw - 1.0, 0.45, h3, size=19, bold=True)
    text(s, gx + 0.35, gy + 0.85, gw - 0.7, 1.2, body, size=15, color=MUTED)
text(s, L, 6.55, CW, 0.35, [[('●', {'color': BLUE}), (' engagement    ', {}), ('●', {'color': ORANGE_DK}),
                             (' competition and community    ', {}), ('●', {'color': SUB}), (' profile and exposure', {})]],
     size=12, color=MUTED)

# ================================================================ 9. EDA cohorts
s = new_slide('3 · EDA · cohorts', 'One hackathon made a cohort look loyal',
              "Four of five cohorts retain 12 to 21 percent, but M12 retains 78 percent. Its month-two activity is a "
              "single spike of about 1,500 users on one day, on a secret-code hackathon. Consequences: the label prior is "
              "not stationary, so we need time-based validation; we test excluding M12 from training; and we added "
              "hackathon and new-competition features.")
r = D['lab_rates']
caption(s, L, 1.6, 5.8, 'Share active in month 2, by sign-up cohort')
bar_chart(s, L, 1.9, 5.8, 3.85, list(r.index), r.values, [ORANGE if k == 'M12' else BLUE for k in r.index],
          cat_title='sign-up cohort', val_max=0.9)
dau = D['dau']
caption(s, 6.9, 1.6, 5.8, 'M12 cohort: daily active users during M1')
cd = CategoryChartData(); cd.categories = [str(int(x)) for x in dau.day]; cd.add_series('users', dau.User_ID.tolist())
ch = s.shapes.add_chart(XL_CHART_TYPE.LINE, Inches(6.9), Inches(1.9), Inches(5.83), Inches(3.85), cd).chart
style_chart(ch); quiet_axes(ch, show_values=True, gridlines=True, cat_title='day of month M1')
ser = ch.plots[0].series[0]; ser.smooth = False
ser.format.line.color.rgb = rgb(ORANGE); ser.format.line.width = Pt(2.5); ser.marker.style = None
from pptx.enum.chart import XL_MARKER_STYLE
ser.marker.style = XL_MARKER_STYLE.NONE
ch.category_axis.tick_label_position = XL_TICK_LABEL_POSITION.LOW
ch.category_axis.tick_labels.font.size = Pt(11)
pk = int(dau.User_ID.values.argmax())
point_label(ser.points[pk], f'{int(dau.User_ID.max()):,} users on day {int(dau.day.iloc[pk])}')
skip_labels(ch.category_axis, 5)
box(s, L, 6.0, CW, 0.75, fill=ORANGE_TINT)
text(s, L + 0.35, 6.0, CW - 0.7, 0.75, [[('So:  ', {'bold': True, 'color': ORANGE_DK}),
     ('time-based validation  ·  test dropping M12 from training  ·  add hackathon features', {})]], size=17,
     anchor=MSO_ANCHOR.MIDDLE)

# ================================================================ 10. EDA engagement
s = new_slide('3 · EDA · engagement', 'Regular, recent users come back',
              "On the typical cohorts, retention rises steadily with the number of active days: 6 percent with no logged "
              "activity up to 55 percent with five or more. Recency matters as much: 39 percent for users seen in the last "
              "two days of the month versus 7 percent for users silent for 15 days or more. Distributions are very "
              "right-skewed, so we log-transform counts for logistic regression; trees do not need it.")
nm = D['normal']
g1 = nm.Active.groupby(pd.cut(nm.n_active_days, [-1, 0, 1, 2, 4, 31], labels=['0', '1', '2', '3–4', '5+']), observed=False).mean()
g2 = nm.Active.groupby(pd.cut(nm.days_since_last, [-1, 2, 7, 14, 31], labels=['0–2', '3–7', '8–14', '15+']), observed=False).mean()
caption(s, L, 1.6, 5.8, 'Regularity: P(active next month) by active days')
bar_chart(s, L, 1.9, 5.8, 3.85, list(g1.index.astype(str)), g1.values, blues(len(g1)),
          cat_title='active days in sign-up month', val_max=0.65)
caption(s, 6.9, 1.6, 5.8, 'Recency: by days since last activity')
bar_chart(s, 6.9, 1.9, 5.83, 3.85, list(g2.index.astype(str)), g2.values, blues(len(g2))[::-1],
          cat_title='days since last activity (at month end)', val_max=0.65)
box(s, L, 6.0, CW, 0.75, fill=BLUE_TINT)
text(s, L + 0.35, 6.0, CW - 0.7, 0.75, [[('So:  ', {'bold': True, 'color': BLUE_DK}),
     ('counts are right-skewed → log1p for the linear model; recency is a key feature', {})]], size=17,
     anchor=MSO_ANCHOR.MIDDLE)

# ================================================================ 11. EDA behaviour and country
s = new_slide('3 · EDA · behaviour and profile', 'Doing beats browsing; country tracks time',
              "Doing things, like submitting, downloading data or joining competitions, predicts retention much better "
              "than reading blog or job pages, so we keep the behaviour breakdown. Country is missing for 10 to 21 "
              "percent of users up to M1 and 64 to 72 percent from M2 on: the sign-up form changed. So we test dropping "
              "country features. Activity features are also strongly collinear (Spearman 0.6 to 0.9), which motivates "
              "regularised logistic regression and tree models.")
names = {'created_submission': 'Created a submission', 'downloaded_competition_datafile': 'Downloaded data',
         'joined_competition': 'Joined a competition', 'new_comps_joined': 'Joined a new competition',
         'discussions': 'Posted in discussions', 'view_blog': 'Read the blog', 'viewed_all_jobs': 'Viewed jobs',
         'joined_hackathon': 'Joined a hackathon', 'viewed_all_learning_pages': 'Viewed learning pages',
         'updated_profile': 'Updated profile'}
rt = D['rates'].sort_values('did')
caption(s, L, 1.6, 7.2, 'Return rate of users who did / did not do X in their first month')
cd = CategoryChartData(); cd.categories = [names[k] for k in rt.index]
cd.add_series('did not', rt['did not'].round(3).tolist()); cd.add_series('did', rt['did'].round(3).tolist())
ch = s.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, Inches(L), Inches(1.9), Inches(7.2), Inches(4.95), cd).chart
style_chart(ch, size=12, legend=True); quiet_axes(ch)
plot = ch.plots[0]; plot.gap_width, plot.overlap = 45, 0
for ser, col in zip(plot.series, (GREY, BLUE)):
    ser.format.fill.solid(); ser.format.fill.fore_color.rgb = rgb(col)
plot.has_data_labels = True
plot.data_labels.number_format, plot.data_labels.number_format_is_linked = '0%', False
plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
plot.data_labels.font.size = Pt(10)
ms = D['miss']
caption(s, 8.25, 1.6, 4.48, 'Users with missing country, by cohort')
bar_chart(s, 8.25, 1.9, 4.48, 2.85, list(ms.index), ms.values, [GREY if i < 3 else ORANGE for i in range(len(ms))],
          label_size=11, val_max=0.85, gap=45)
text(s, 8.25, 4.95, 4.48, 1.8, [[('The jump at M2 is a ', {}), ('sign-up form change', {'bold': True}),
     (', not behaviour. Country acts as a time proxy, so we test dropping it.', {})]], size=15)

# ================================================================ 12. validation
s = new_slide('4 · Validation and metric', 'Validate the way we deploy',
              "In deployment the model is trained on past cohorts and applied to a new one, so we validate the same way: "
              "train on earlier cohorts, validate on the next. Hyper-parameters and the model family are chosen on the two "
              "inner folds only. M3 is a hold-out cohort scored exactly once. Positives are rare, so accuracy is useless; "
              "we report F1, select models on PR-AUC, and tune the threshold on out-of-fold predictions.",
              footnote='"train?" = keeping M12 in training is itself a tuned choice')
cols = ['M11', 'M12', 'M1', 'M2', 'M3']
gx0, cw2, gap2 = L + 2.2, 1.85, 0.15
text(s, L, 1.75, 2.1, 0.4, 'forward chaining', size=13, color=MUTED)
for j, c in enumerate(cols):
    text(s, gx0 + j * (cw2 + gap2), 1.75, cw2, 0.4, c, size=15, bold=True, align=PP_ALIGN.CENTER)
plan = [('Inner fold 1', ['train', 'train?', 'validate', '', '']),
        ('Inner fold 2', ['train', 'train?', 'train', 'validate', '']),
        ('Hold-out test', ['train', 'train?', 'train', 'train', 'test once'])]
for i, (name, cells) in enumerate(plan):
    yy = 2.25 + i * 0.68
    text(s, L, yy, 2.1, 0.52, name, size=16, bold=True, anchor=MSO_ANCHOR.MIDDLE)
    for j, c in enumerate(cells):
        xx = gx0 + j * (cw2 + gap2)
        if c == 'train':
            label_box(s, xx, yy, cw2, 0.52, c, BLUE_LT, INK)
        elif c == 'train?':
            label_box(s, xx, yy, cw2, 0.52, c, WHITE, MUTED, line=GREY, dash=True)
        elif c == 'validate':
            label_box(s, xx, yy, cw2, 0.52, c, BLUE, WHITE, bold=True)
        elif c == 'test once':
            label_box(s, xx, yy, cw2, 0.52, c, ORANGE_DK, WHITE, bold=True)
metrics = [('Score: F1, positive class', 'Competition metric. With 12% positives, "all inactive" gets 88% accuracy but F1 = 0.'),
           ('Select on PR-AUC', 'Threshold-free and focused on the minority class.'),
           ('Tune the threshold', 'Maximise F1 on out-of-fold predictions of the inner folds.')]
for k, (h3, body) in enumerate(metrics):
    mx = L + k * (cwid + 0.3)
    box(s, mx, 4.55, cwid, 2.0, fill=CARD)
    text(s, mx + 0.3, 4.8, cwid - 0.6, 0.45, h3, size=18, bold=True)
    text(s, mx + 0.3, 5.3, cwid - 0.6, 1.2, body, size=15, color=MUTED)

# ================================================================ 13. random K-fold
s = new_slide('4 · Why not random K-fold?', 'Random K-fold overstates quality about 2×',
              "A demonstration with the same untuned gradient-boosting model. Random 5-fold mixes all cohorts and reports "
              "PR-AUC 0.85. Forward validation gives 0.30 on M1, 0.47 on M2 and 0.46 on M3. Part of the gap is the higher "
              "base rate when M12 is mixed in, but mostly the model learns cohort-specific signals that do not carry over.",
              footnote='same gradient-boosting model, default settings')
caption(s, L, 1.6, 6.6, 'PR-AUC of one model under two validation schemes')
bar_chart(s, L, 1.9, 6.6, 4.4, ['Random 5-fold', 'Forward → M1', 'Forward → M2', 'Forward → M3'],
          [0.849, 0.296, 0.469, 0.464], [GREY, BLUE, BLUE, BLUE], fmt='0.00', val_max=1.0, gap=55)
box(s, 7.6, 1.75, 5.13, 1.45, fill=CARD)
text(s, 7.95, 1.9, 1.9, 1.15, '0.85', size=44, bold=True, color=SUB, anchor=MSO_ANCHOR.MIDDLE)
text(s, 9.85, 1.9, 2.7, 1.15, 'random 5-fold: looks great, but is not honest', size=15, color=MUTED, anchor=MSO_ANCHOR.MIDDLE)
box(s, 7.6, 3.4, 5.13, 1.45, fill=BLUE_TINT)
text(s, 7.95, 3.55, 2.6, 1.15, '0.30–0.47', size=40, bold=True, color=BLUE, anchor=MSO_ANCHOR.MIDDLE)
text(s, 10.55, 3.55, 2.0, 1.15, 'forward chaining: what we can expect', size=15, color=MUTED, anchor=MSO_ANCHOR.MIDDLE)
text(s, 7.6, 5.1, 5.13, 1.6, [[('The model memorises ', {}), ('cohort-specific signals', {'bold': True}),
     (' (which hackathon ran, whether country was recorded) that do not transfer to a future cohort.', {})]], size=15)

# ================================================================ 14. models
s = new_slide('4 · Models and search', 'From rule of thumb to gradient boosting',
              "Four candidates. The rule of thumb is the honest baseline: what you would do without ML. Logistic "
              "regression is interpretable and its regularisation handles collinear counts. Random forest and histogram "
              "gradient boosting are standard non-linear models for tabular data. Each is tuned with GridSearchCV on the "
              "forward folds, with and without M12 and with and without country features.")
rows = [['Model', 'Why this model', 'Grid searched'],
        ['Rule of thumb: active on ≥ k days', 'What a product manager would do without ML', 'k = 1 … 9'],
        ['Logistic regression (log1p, scaling, L2, balanced)', 'Interpretable; L2 copes with collinear counts (ρ 0.6–0.9)', 'C: 6 values'],
        ['Random forest (class-balanced)', 'Non-linear, robust, few assumptions', 'depth, leaf size, max features (18)'],
        ['Histogram gradient boosting', 'Strong on skewed tabular counts and interactions', 'rate, trees, leaves, leaf size, L2 (48)']]
table(s, L, 1.7, CW, rows, [0.36, 0.38, 0.26], size=15, row_h=0.72)
box(s, L, 5.6, CW, 0.95, fill=BLUE_TINT)
text(s, L + 0.35, 5.6, CW - 0.7, 0.95, [[('GridSearchCV on our forward folds, scored by PR-AUC, crossed with two data '
     'choices from the EDA: ', {}), ('keep or drop M12', {'bold': True}), (' and ', {}),
     ('keep or drop country', {'bold': True}), ('.', {})]], size=16, anchor=MSO_ANCHOR.MIDDLE)

# ================================================================ 15. tuning results
res = D['res']
best_side = res.groupby(['model', 'train_M12']).cv_PR_AUC.max().unstack()
order = ['GradBoost', 'RandomForest', 'LogReg']
nice_m = {'GradBoost': 'Gradient boosting', 'RandomForest': 'Random forest', 'LogReg': 'Logistic regression'}
s = new_slide('4 · Search results', 'Dropping the hackathon cohort helps every model',
              "Leaving the event-driven M12 cohort out of training improves every model: it teaches the wrong base rate and "
              "the wrong patterns. Country features have a small and inconsistent effect. Gradient boosting has the best "
              "cross-validated PR-AUC, 0.508, so it becomes the final model, chosen on CV only, before we look at the hold-out.",
              footnote='CV PR-AUC, mean of 2 forward folds, best feature set per bar')
caption(s, L, 1.6, 6.9, 'Cross-validated PR-AUC, M12 kept vs dropped from training')
cd = CategoryChartData(); cd.categories = [nice_m[m] for m in order]
cd.add_series('M12 kept', [round(best_side.loc[m, 'kept'], 3) for m in order])
cd.add_series('M12 dropped', [round(best_side.loc[m, 'dropped'], 3) for m in order])
ch = s.shapes.add_chart(XL_CHART_TYPE.COLUMN_CLUSTERED, Inches(L), Inches(1.9), Inches(6.9), Inches(4.75), cd).chart
style_chart(ch, legend=True); quiet_axes(ch)
ch.value_axis.minimum_scale, ch.value_axis.maximum_scale = 0, 0.6
plot = ch.plots[0]; plot.gap_width, plot.overlap = 70, -10
for ser, col in zip(plot.series, (GREY, BLUE)):
    ser.format.fill.solid(); ser.format.fill.fore_color.rgb = rgb(col)
plot.has_data_labels = True
plot.data_labels.number_format, plot.data_labels.number_format_is_linked = '0.000', False
plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
plot.data_labels.font.size, plot.data_labels.font.bold = Pt(13), True
box(s, 7.9, 1.75, 4.83, 1.5, fill=BLUE_TINT)
text(s, 8.2, 1.85, 1.9, 1.3, '+0.08', size=40, bold=True, color=BLUE, anchor=MSO_ANCHOR.MIDDLE)
text(s, 10.1, 1.85, 2.5, 1.3, 'for boosting when M12 leaves training (0.43 → 0.51)', size=14, color=MUTED, anchor=MSO_ANCHOR.MIDDLE)
text(s, 7.9, 3.5, 4.83, 0.4, 'Selected configurations', size=17, bold=True)
cfg = [('Gradient boosting  ', 'no country · lr 0.03 · 100 trees · 7 leaves · min leaf 80 · L2 1.0'),
       ('Random forest  ', 'all features · depth 6 · max features 0.4 · min leaf 50'),
       ('Logistic regression  ', 'no country · C = 0.003')]
text(s, 7.9, 3.95, 4.83, 2.6, [[(a, {'bold': True}), (b, {'color': MUTED})] for a, b in cfg], size=14, spacing=10)

# ================================================================ 16. hold-out results
f = D['final']
s = new_slide('5 · Results', 'Unseen cohort M3: F1 = 0.47',
              "On the hold-out cohort, scored once, gradient boosting reaches F1 0.47 with precision 0.45, recall 0.49 and "
              "ROC-AUC 0.83. Logistic regression is marginally higher at 0.48, but that difference is within the noise of a "
              "cohort with 243 positives, so we keep the model chosen on cross-validation. Every ML model beats the rule "
              "of thumb by about 0.11 F1 and the trivial everyone-active rule by 0.25.",
              footnote='threshold 0.32, tuned on out-of-fold predictions')
lab = {'GradBoost': 'Gradient boosting (chosen)', 'LogReg': 'Logistic regression', 'RandomForest': 'Random forest',
       'Baseline (active days >= 2)': 'Rule: active ≥ 2 days', 'Predict everyone active': 'Predict everyone active'}
order = ['Predict everyone active', 'Baseline (active days >= 2)', 'RandomForest', 'LogReg', 'GradBoost']
caption(s, L, 1.6, 7.6, 'F1 (positive class) on hold-out cohort M3')
bar_chart(s, L, 1.9, 7.6, 4.8, [lab[k] for k in order], [round(f.loc[k, 'F1'], 2) for k in order],
          [GREY, GREY, BLUE_LT, BLUE_LT, BLUE], fmt='0.00', horizontal=True, val_max=0.6, gap=50, label_size=15)
stats = [('0.45', 'precision'), ('0.49', 'recall'), ('0.83', 'ROC-AUC'), ('+0.11', 'F1 vs the rule')]
for k, (big, small) in enumerate(stats):
    sx, sy = 8.6 + (k % 2) * 2.13, 1.75 + (k // 2) * 1.45
    box(s, sx, sy, 2.0, 1.3, fill=BLUE_TINT if k == 3 else CARD)
    text(s, sx + 0.25, sy + 0.15, 1.6, 0.65, big, size=30, bold=True, color=BLUE)
    text(s, sx + 0.25, sy + 0.8, 1.6, 0.4, small, size=13, color=MUTED)
text(s, 8.6, 4.85, 4.13, 1.8, [[('The three ML models differ by ≤ 0.02 F1: noise for 243 positives. We keep the ', {}),
     ('CV-selected', {'bold': True}), (' model; no cherry-picking on the hold-out.', {})]], size=15)

# ================================================================ 17. drivers
s = new_slide('5 · What drives the model', 'Recency drives the prediction',
              "Days since last activity is by far the most important feature. Next come regularity, the successful-"
              "submission bucket, active days and hackathon participation. Profile variables contribute little: only the "
              "masked FeatureX is in the top ten, and country was dropped by the search. So engagement is about behaviour, "
              "not demographics. At the chosen threshold the model finds 120 of 243 returners with 45 percent precision.")
imp = D['imp'].head(10)[::-1]
nice = {'days_since_last': 'Days since last activity', 'active_day_ratio': 'Active-day ratio',
        'max_sub_bucket': 'Successful submissions', 'n_active_days': 'Active days', 'joined_hackathon': 'Joined hackathon',
        'FeatureX': 'FeatureX (profile)', 'n_joined_competition': 'Joined competition',
        'n_created_submission': 'Submissions created', 'n_distinct_comps': 'Distinct competitions',
        'days_observed': 'Days observed'}
grp = {'days_since_last': BLUE, 'active_day_ratio': BLUE, 'n_active_days': BLUE, 'FeatureX': GREY, 'days_observed': GREY}
text(s, L, 1.6, 7.4, 0.3, [[('Permutation importance on M3:  ', {}), ('■ recency / regularity  ', {'color': BLUE}),
     ('■ doing  ', {'color': ORANGE_DK}), ('■ profile / exposure', {'color': SUB})]], size=13, color=MUTED)
bar_chart(s, L, 1.9, 7.4, 4.85, [nice.get(k, k) for k in imp.index], imp.round(3).values,
          [grp.get(k, ORANGE) for k in imp.index], fmt='0.000', horizontal=True, val_max=0.16, gap=40, label_size=12,
          label_color=MUTED)
caption(s, 8.45, 1.6, 4.28, 'Confusion matrix, M3 (2,000 users)')
cells = [('1,611', 'inactive, predicted inactive', 'E4E9F0', INK, MUTED), ('146', 'inactive, predicted active', CARD, SUB, MUTED),
         ('123', 'active, predicted inactive', CARD, SUB, MUTED), ('120', 'active, predicted active', BLUE, WHITE, 'E4EBFA')]
for k, (big, small, fill, c1, c2) in enumerate(cells):
    cx, cy = 8.45 + (k % 2) * 2.19, 1.95 + (k // 2) * 1.6
    box(s, cx, cy, 2.09, 1.45, fill=fill)
    text(s, cx + 0.22, cy + 0.15, 1.7, 0.6, big, size=28, bold=True, color=c1)
    text(s, cx + 0.22, cy + 0.78, 1.7, 0.6, small, size=12, color=c2)
text(s, 8.45, 5.3, 4.28, 1.4, [[('Behaviour, not demographics', {'bold': True}),
     (': good for fairness and for action.', {})]], size=15)

# ================================================================ 18. impact
s = new_slide('5 · Real-world impact', 'Ranking puts returners at the top',
              "A retention campaign has a budget, so what matters is ranking. The top 20 percent of users by score contain "
              "63 percent of all users who return. The top decile is four times more likely to return than average, and "
              "the bottom half contains only 13 percent of returners.")
sh, cp = D['share'], D['cum_pos']
idx = np.unique(np.r_[np.linspace(0, len(sh) - 1, 120).astype(int), int(.2 * len(sh)) - 1])
caption(s, L, 1.6, 5.8, 'Cumulative gains on M3')
xy = XyChartData()
m = xy.add_series('model ranking')
for i in idx:
    m.add_data_point(round(float(sh[i]), 4), round(float(cp[i]), 4))
rnd = xy.add_series('random targeting'); rnd.add_data_point(0, 0); rnd.add_data_point(1, 1)
ch = s.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER_LINES_NO_MARKERS, Inches(L), Inches(1.9), Inches(5.8), Inches(4.0), xy).chart
style_chart(ch, size=12, legend=True)
for ax, t in ((ch.category_axis, 'share of cohort contacted'), (ch.value_axis, 'share of returners captured')):
    ax.minimum_scale, ax.maximum_scale, ax.major_unit = 0, 1, 0.2
    ax.tick_labels.number_format, ax.tick_labels.number_format_is_linked = '0%', False
    ax.has_major_gridlines = True; ax.major_gridlines.format.line.color.rgb = rgb('E6E9EE')
    ax.format.line.color.rgb = rgb(LINE)
    ax.has_title = True; ax.axis_title.text_frame.text = t
    ft = ax.axis_title.text_frame.paragraphs[0].runs[0].font; ft.size, ft.bold, ft.color.rgb = Pt(12), False, rgb(MUTED)
s1, s2 = ch.plots[0].series
s1.format.line.color.rgb = rgb(BLUE); s1.format.line.width = Pt(3); s1.smooth = False
s2.format.line.color.rgb = rgb(GREY); s2.format.line.width = Pt(1.5); s2.smooth = False
from pptx.enum.dml import MSO_LINE_DASH_STYLE
s2.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH
k20 = int(np.where(idx == int(.2 * len(sh)) - 1)[0][0])
pt = s1.points[k20]
pt.marker.style = XL_MARKER_STYLE.CIRCLE; pt.marker.size = 9
pt.marker.format.fill.solid(); pt.marker.format.fill.fore_color.rgb = rgb(BLUE)
text(s, 3.95, 4.2, 2.3, 0.75, [[('● ', {'color': BLUE}), ('Top 20% contacted', {'bold': True})],
                               [('captures 63% of returners', {})]], size=12, color=BLUE_DK)
lift = D['lift'].copy(); lift.index = lift.index.astype(int); lift = lift.sort_index()
caption(s, 6.9, 1.6, 5.83, 'Lift by decile of predicted probability (1.0× = average)')
ch = bar_chart(s, 6.9, 1.9, 5.83, 4.0, [str(i) for i in lift.index], lift.round(1).values,
               [BLUE if i <= 2 else GREY for i in lift.index], fmt='0.0"×"', cat_title='decile (1 = highest score)',
               val_max=4.5, gap=40, label_size=11)
ch.value_axis.has_major_gridlines = True
ch.value_axis.major_unit = 1
ch.value_axis.major_gridlines.format.line.color.rgb = rgb('E6E9EE')
box(s, L, 6.1, CW, 0.7, fill=BLUE_TINT)
for k, (big, small) in enumerate([('63%', ' of returners in the top 20%'), ('4×', ' average in the top decile'),
                                  ('13%', ' of returners in the bottom half')]):
    text(s, L + 0.35 + k * 4.0, 6.1, 3.9, 0.7, [[(big, {'bold': True, 'color': BLUE_DK}), (small, {})]], size=17,
         anchor=MSO_ANCHOR.MIDDLE)

# ================================================================ 19. business case
s = new_slide('5 · Illustrative business case', 'Targeting the uncertain middle cuts campaign cost by ~60%',
              "An illustrative business case with stated assumptions: 2,000 sign-ups a month and 5 dollars per "
              "intervention. Contacting everybody costs 10,000 dollars. The bottom half holds very few returners, so a "
              "costly personal intervention can focus on the middle deciles, users with some engagement but an uncertain "
              "outcome. Contacting that 40 percent costs 4,000 dollars, 60 percent less. The top decile is a natural "
              "shortlist for community programmes. The causal effect must be measured with an A/B test.",
              footnote='assumed numbers, to be replaced by Zindi\'s')
nums = [('$10,000', 'contact all 2,000 monthly sign-ups at $5 each', CARD, SUB),
        ('$4,000', 'contact only the 40% the model is unsure about', BLUE_TINT, BLUE),
        ('Top 10%', 'shortlist for hackathon and ambassador invitations', CARD, INK)]
for k, (big, small, fill, col) in enumerate(nums):
    nx = L + k * (cwid + 0.3)
    box(s, nx, 2.0, cwid, 2.7, fill=fill)
    text(s, nx + 0.4, 2.35, cwid - 0.8, 1.0, big, size=48, bold=True, color=col)
    text(s, nx + 0.4, 3.45, cwid - 0.8, 1.1, small, size=17, color=MUTED)
label_box(s, L + cwid + 0.3 - 0.02, 1.75, 1.3, 0.42, '−60%', BLUE, WHITE, bold=True, size=15)
text(s, L, 5.15, CW, 1.2, [[('The bottom half of scores holds only 13% of returners, so personal outreach should go to the '
     'middle deciles. The ', {}), ('causal', {'italic': True}), (' effect of a campaign still needs an ', {}),
     ('A/B test', {'bold': True}), ('.', {})]], size=17)

# ================================================================ 20. conclusions
s = new_slide('6 · Conclusions', 'Did the model solve the problem?',
              "Largely for ranking, partly for exact classification. On an unseen future cohort the model reaches F1 0.47 "
              "against 0.36 for the best rule of thumb, and it puts 63 percent of returners in the top fifth of users. F1 "
              "stays moderate because many returns are triggered by future events such as new competitions and hackathons. "
              "The biggest lessons came from validation design and non-stationary data, more than from model choice. For "
              "the official M4 cohort we predict 10.9 percent active, consistent with the 12 percent base rate.",
              footnote='submission: 1,340 M4 users scored; predicted active share 10.9% (base rate ≈ 12%)')
box(s, L, 1.7, CW, 1.15, fill=BLUE_TINT)
text(s, L + 0.35, 1.7, CW - 0.7, 1.15, [[('Yes for ranking, partly for exact labels. ', {'bold': True}),
     ('F1 0.47 vs 0.36 for the best rule; the top 20% holds 63% of returners. Many returns are driven by future '
      'events that are invisible in month 1.', {})]], size=17, anchor=MSO_ANCHOR.MIDDLE)
cols3 = [('Findings', BLUE, ['Recency and regularity beat demographics', 'Doing beats browsing',
                             'Retention is non-stationary: events, form changes']),
         ('Lessons and limits', ORANGE_DK, ['Validation design mattered more than model choice',
                                            'Only 5 labelled cohorts; masked features', 'M4 log ends on day 22']),
         ('Next steps', INK, ['Add the competition calendar as features', 'Train on more cohorts; calibrate per cohort',
                              'A/B-test a retention campaign'])]
for k, (h3, col, items) in enumerate(cols3):
    cx = L + k * (cwid + 0.3)
    box(s, cx, 3.1, cwid, 3.55, fill=CARD)
    text(s, cx + 0.35, 3.35, cwid - 0.7, 0.45, h3, size=19, bold=True, color=col)
    tb = text(s, cx + 0.35, 3.95, cwid - 0.7, 2.6, items, size=15, spacing=8)
    for p in tb.text_frame.paragraphs:
        pPr = p._p.get_or_add_pPr()
        pPr.set('marL', str(Inches(0.22))); pPr.set('indent', str(-Inches(0.22)))
        from pptx.oxml.ns import qn
        bu = pPr.makeelement(qn('a:buChar'), {'char': '•'})
        pPr.append(bu)

# ================================================================ 21. thanks
s = new_slide(None, None, 'Thank the audience and invite questions.')
s.background.fill.fore_color.rgb = rgb('F5F7FB')
text(s, L, 2.3, 9, 1.2, 'Thank you', size=60, bold=True)
text(s, L, 3.5, 9, 0.6, 'Questions?', size=24, color=MUTED)
text(s, L, 4.7, 11, 1.0, [[('Code: ', {}), ('zindi_engagement.ipynb', {'color': BLUE_DK, 'font': MONO}),
                          ('   ·   Video: ', {}), ('[link]', {'color': BLUE_DK})],
                         [('[Team name]  ·  [Member 1]  ·  [Member 2]  ·  [Member 3]', {})]], size=16, color=MUTED, spacing=6)

prs.save(OUT)
print('written', OUT, len(prs.slides._sldIdLst), 'slides')
