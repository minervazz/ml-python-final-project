"""Assemble deck-source/ into one HTML file and print it to PDF with headless Chrome.
Run: python build_slides.py   (from pre/slides)"""
import json, re, subprocess, pathlib
HERE = pathlib.Path(__file__).parent
SRC = HERE / 'deck-source'
BLOB = {'0a3630b298fa5e3ecf0695619d855d5c': 'c1_heatmap', '6f9471e90a47339e8fdb37c6f59f7b96': 'c2_cohort',
        '235fb306c5d8b043b92acc76650d1f2f': 'c3_spike', '4ab4f10b35644f40ac1544a5c7eb823d': 'c4_regularity',
        'f9170aa6f8a2c4e5a01abc8e059d86d7': 'c5_recency', 'e42af3c1a06218d2bb8bc0360726a38b': 'c6_behaviour',
        'f1b73c07a855b7cea3a62b5ffd4d769a': 'c7_country', '959e68e4c5b6232f09c0d6b7d897ce26': 'c8_holdout',
        '524e0ad4b7ae71d78a78884f6afdf391': 'c9_importance', '9f29d76d6d55cc281b7cb25f6b8c46c1': 'c10_gains',
        'f9666fb0f6903846adbe8b40b74d61d7': 'c11_lift'}
ICONS = {'Users': '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
         'Star': '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
         'Lightbulb': '<path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.3h6c0-1 .4-1.8 1-2.3A7 7 0 0 0 12 2z"/>',
         'Lock': '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>'}

def icon(m):
    name, style = m.group(1), m.group(2)
    color = re.search(r'color:([^;]+)', style).group(1)
    size = re.search(r'width:(\d+)px', style).group(1)
    return (f'<svg width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="2" '
            f'stroke-linecap="round" stroke-linejoin="round">{ICONS[name]}</svg>')

deck = json.loads((SRC / 'deck.json').read_text())
fonts = '\n'.join(f'<link rel="stylesheet" href="{f["href"]}">' for f in deck['faces'].values())
slides = []
for sid in deck['order']:
    s = (SRC / 'slides' / f'{sid}.html').read_text()
    s = re.sub(r'<aside>.*?</aside>', '', s, flags=re.S)
    s = re.sub(r'/_blob/([0-9a-f]{32})', lambda m: f'charts/{BLOB[m.group(1)]}.png', s)
    s = re.sub(r'<x-icon name="(\w+)" style="([^"]*)"></x-icon>', icon, s)
    slides.append(s)

css = """@page { size: 1920px 1080px; margin: 0 }
* { box-sizing: border-box }
html, body { margin: 0; padding: 0; background: #888 }
section { width: 1920px; height: 1080px; position: relative; overflow: hidden; break-after: page }
h1, h2, h3, p, ul, hr { margin: 0 }
p { font-size: 32px; line-height: 1.4 }
div { min-width: 0 }
div:not([style*="display"]) { display: flex; flex-direction: column }
img, svg { display: block; flex: none }
ul { padding-left: 1.2em; display: flex; flex-direction: column; gap: 8px }
hr { border: none }
table { border-collapse: collapse; flex: none }
td, th { border-top: 1px solid #D9DEE4; vertical-align: top; line-height: 1.3 }
th { font-weight: 600 }"""
html = f"""<!doctype html><html><head><meta charset="utf-8"><title>{deck['title']}</title>
{fonts}<style>{css}</style></head><body>
{''.join(slides)}
</body></html>"""
(HERE / 'zindi_engagement_slides.html').write_text(html)
chrome = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
subprocess.run([chrome, '--headless=new', '--disable-gpu', '--no-pdf-header-footer', '--virtual-time-budget=15000',
                '--run-all-compositor-stages-before-draw', f'--print-to-pdf={HERE.parent / "zindi_engagement_slides.pdf"}',
                (HERE / 'zindi_engagement_slides.html').as_uri()], check=True, capture_output=True)
print('written', HERE.parent / 'zindi_engagement_slides.pdf')
