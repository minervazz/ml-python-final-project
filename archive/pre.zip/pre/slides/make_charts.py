import pickle, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from sklearn.metrics import precision_recall_curve
S = '/private/tmp/claude-501/-Users-minervazz-Documents-MBZUAI-Fall-2026-ML-with-Python-final-project/48f0978b-ee31-4ae7-b139-e914093aa349/scratchpad/'
d = pickle.load(open(S + 'nb_out.pkl', 'rb'))
INK, MUTED, GRID, BLUE, ORANGE, GREY, LIGHT = '#1B2433', '#5B6575', '#D9DEE4', '#2F5FD0', '#D9691F', '#AEB6C1', '#C9D6F2'
fam = 'Helvetica Neue' if any('Helvetica Neue' in f.name for f in fm.fontManager.ttflist) else 'Arial'
plt.rcParams.update({'font.family': fam, 'font.size': 16, 'axes.edgecolor': GRID, 'axes.labelcolor': MUTED,
                     'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titlesize': 17, 'axes.labelsize': 16, 'xtick.labelsize': 15, 'ytick.labelsize': 15,
                     'text.color': INK, 'axes.grid': False, 'savefig.dpi': 200})

def save(fig, name):
    fig.tight_layout(); fig.savefig(S + 'charts/' + name, transparent=True); plt.close(fig)

def clean_y(ax):
    ax.spines['left'].set_visible(False); ax.set_yticks([])

# 1. sign-up x activity heatmap
ct = d['ct']
fig, ax = plt.subplots(figsize=(9.5, 4.6))
v = np.log10(ct.values + 1)
ax.imshow(v, cmap='Blues', aspect='auto', vmin=0, vmax=v.max())
for i in range(ct.shape[0]):
    for j in range(ct.shape[1]):
        n = ct.values[i, j]
        ax.text(j, i, f'{n:,}' if n else '0', ha='center', va='center', fontsize=13,
                color='white' if v[i, j] > 3.3 else (GREY if n == 0 else INK))
ax.set_xticks(range(ct.shape[1]), ct.columns); ax.set_yticks(range(ct.shape[0]), ct.index)
ax.set_xlabel('activity month'); ax.set_ylabel('sign-up cohort')
for s in ax.spines.values(): s.set_visible(False)
ax.tick_params(length=0)
save(fig, 'c1_heatmap.png')

# 2. retention by cohort
r = d['lab_rates']
fig, ax = plt.subplots(figsize=(7.2, 4.6))
cols = [ORANGE if k == 'M12' else BLUE for k in r.index]
ax.bar(r.index, r.values, color=cols, width=0.62)
for i, (k, val) in enumerate(r.items()):
    ax.text(i, val + 0.02, f'{val:.0%}', ha='center', fontsize=17, fontweight='bold', color=cols[i])
ax.set_ylim(0, 0.9); clean_y(ax); ax.set_xlabel('sign-up cohort'); ax.tick_params(length=0)
save(fig, 'c2_cohort.png')

# 3. M12 daily active users in M1
dau = d['dau']
fig, ax = plt.subplots(figsize=(7.2, 4.6))
ax.plot(dau.day, dau.User_ID, color=ORANGE, lw=2.5)
ax.fill_between(dau.day, dau.User_ID, color=ORANGE, alpha=0.12)
pk = dau.loc[dau.User_ID.idxmax()]
ax.annotate(f'{int(pk.User_ID):,} users on day {int(pk.day)}', (pk.day, pk.User_ID), xytext=(pk.day + 2.5, pk.User_ID * 0.85),
            fontsize=16, color=INK, arrowprops=dict(arrowstyle='-', color=MUTED))
ax.set_xlabel('day of month M1'); ax.set_ylabel('active users'); ax.tick_params(length=0)
ax.yaxis.grid(True, color=GRID); ax.set_axisbelow(True); ax.spines['left'].set_visible(False)
save(fig, 'c3_spike.png')

# 4/5. regularity and recency
nm = d['normal']
def rate_bars(series, bins, labels, name, xlabel, rising):
    g = nm.Active.groupby(pd.cut(series, bins, labels=labels), observed=False).mean()
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    shades = plt.cm.Blues(np.linspace(0.35, 0.85, len(g)))
    if not rising: shades = shades[::-1]
    ax.bar(g.index.astype(str), g.values, color=shades, width=0.62)
    for i, val in enumerate(g.values):
        ax.text(i, val + 0.015, f'{val:.0%}', ha='center', fontsize=17, fontweight='bold', color=INK)
    ax.set_ylim(0, max(g.values) * 1.2); clean_y(ax); ax.set_xlabel(xlabel); ax.tick_params(length=0)
    save(fig, name); return g
print(rate_bars(nm.n_active_days, [-1, 0, 1, 2, 4, 31], ['0', '1', '2', '3–4', '5+'], 'c4_regularity.png', 'active days in sign-up month', True))
print(rate_bars(nm.days_since_last, [-1, 2, 7, 14, 31], ['0–2', '3–7', '8–14', '15+'], 'c5_recency.png', 'days since last activity (at month end)', False))

# 6. behaviour dumbbell
rt = d['rates'].copy()
names = {'created_submission': 'Created a submission', 'downloaded_competition_datafile': 'Downloaded data',
         'joined_competition': 'Joined a competition', 'new_comps_joined': 'Joined a new competition',
         'discussions': 'Posted in discussions', 'view_blog': 'Read the blog', 'viewed_all_jobs': 'Viewed jobs',
         'joined_hackathon': 'Joined a hackathon', 'viewed_all_learning_pages': 'Viewed learning pages',
         'updated_profile': 'Updated profile'}
doing = {'created_submission', 'downloaded_competition_datafile', 'joined_competition', 'new_comps_joined', 'discussions'}
rt = rt.sort_values('did')
fig, ax = plt.subplots(figsize=(9.5, 5.6))
for i, (k, row) in enumerate(rt.iterrows()):
    c = BLUE if k in doing else GREY
    ax.plot([row['did not'], row['did']], [i, i], color=c, lw=3, alpha=0.6)
    ax.scatter(row['did not'], i, s=90, color='white', edgecolor=c, lw=2, zorder=3)
    ax.scatter(row['did'], i, s=110, color=c, zorder=3)
    ax.text(row['did'] + 0.012, i, f'{row["did"]:.0%}', va='center', fontsize=15, color=c, fontweight='bold')
ax.set_yticks(range(len(rt)), [names[k] for k in rt.index]); ax.tick_params(length=0)
ax.set_xlim(0.05, 0.47); ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, 0))
ax.set_xlabel('P(active next month)  ·  hollow = did not, filled = did'); ax.xaxis.grid(True, color=GRID); ax.set_axisbelow(True)
ax.spines['left'].set_visible(False)
save(fig, 'c6_behaviour.png')

# 7. country missing share
ms = d['miss']
fig, ax = plt.subplots(figsize=(7.2, 4.6))
cols = [GREY if i < 3 else ORANGE for i in range(len(ms))]
ax.bar(ms.index, ms.values, color=cols, width=0.62)
for i, val in enumerate(ms.values):
    ax.text(i, val + 0.02, f'{val:.0%}', ha='center', fontsize=16, fontweight='bold', color=cols[i] if i >= 3 else MUTED)
ax.set_ylim(0, 0.85); clean_y(ax); ax.set_xlabel('sign-up cohort'); ax.tick_params(length=0)
save(fig, 'c7_country.png')

# 8. hold-out F1
f = d['final']
lab = {'GradBoost': 'Gradient boosting (chosen)', 'LogReg': 'Logistic regression', 'RandomForest': 'Random forest',
       'Baseline (active days >= 2)': 'Rule: active ≥ 2 days', 'Predict everyone active': 'Predict everyone active'}
order = ['GradBoost', 'LogReg', 'RandomForest', 'Baseline (active days >= 2)', 'Predict everyone active'][::-1]
fig, ax = plt.subplots(figsize=(9.5, 4.8))
cols = [BLUE if k == 'GradBoost' else (LIGHT if k in ('LogReg', 'RandomForest') else GREY) for k in order]
ax.barh([lab[k] for k in order], f.loc[order, 'F1'], color=cols, height=0.62)
for i, k in enumerate(order):
    ax.text(f.loc[k, 'F1'] + 0.008, i, f'{f.loc[k, "F1"]:.2f}', va='center', fontsize=17, fontweight='bold', color=INK)
ax.set_xlim(0, 0.56); ax.set_xticks([]); ax.spines['bottom'].set_visible(False); ax.spines['left'].set_visible(False)
ax.tick_params(length=0, labelsize=16); ax.set_xlabel('F1 (positive class) on hold-out cohort M3')
save(fig, 'c8_holdout.png')

# 9. permutation importance
imp = d['imp'].head(10)[::-1]
nice = {'days_since_last': 'Days since last activity', 'active_day_ratio': 'Active-day ratio', 'max_sub_bucket': 'Successful submissions',
        'n_active_days': 'Active days', 'joined_hackathon': 'Joined hackathon', 'FeatureX': 'FeatureX (profile)',
        'n_joined_competition': 'Joined competition', 'n_created_submission': 'Submissions created',
        'n_distinct_comps': 'Distinct competitions', 'days_observed': 'Days observed'}
grp = {'days_since_last': BLUE, 'active_day_ratio': BLUE, 'n_active_days': BLUE, 'FeatureX': GREY, 'days_observed': GREY}
fig, ax = plt.subplots(figsize=(9.5, 5.6))
cols = [grp.get(k, ORANGE) for k in imp.index]
ax.barh([nice.get(k, k) for k in imp.index], imp.values, color=cols, height=0.62)
for i, val in enumerate(imp.values):
    ax.text(val + 0.002, i, f'{val:.3f}', va='center', fontsize=14, color=MUTED)
ax.set_xticks([]); ax.spines['bottom'].set_visible(False); ax.spines['left'].set_visible(False); ax.tick_params(length=0)
ax.set_xlabel('drop in PR-AUC when the feature is shuffled'); ax.set_xlim(0, 0.15)
save(fig, 'c9_importance.png')

# 10. cumulative gains
sh, cp = d['share'], d['cum_pos']
fig, ax = plt.subplots(figsize=(7.4, 5.0))
ax.plot([0, 1], [0, 1], '--', color=GREY, lw=1.8, label='random targeting')
ax.plot(sh, cp, color=BLUE, lw=3, label='model ranking')
k = int(.2 * len(sh)) - 1
ax.scatter([0.2], [cp[k]], s=90, color=BLUE, zorder=3)
ax.annotate(f'top 20% contacted\n= {cp[k]:.0%} of returners', (0.2, cp[k]), xytext=(0.02, 0.86), fontsize=16, color=INK,
            arrowprops=dict(arrowstyle='-', color=MUTED))
ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, 0)); ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1, 0))
ax.set_xlabel('share of cohort contacted'); ax.set_ylabel('share of returners captured')
ax.grid(True, color=GRID); ax.set_axisbelow(True); ax.legend(frameon=False, loc='lower right', fontsize=14); ax.tick_params(length=0)
save(fig, 'c10_gains.png')

# 11. lift by decile
lift = d['lift']; lift.index = lift.index.astype(int); lift = lift.sort_index()
fig, ax = plt.subplots(figsize=(7.4, 5.0))
cols = [BLUE if i <= 2 else GREY for i in lift.index]
ax.bar(lift.index.astype(str), lift.values, color=cols, width=0.62)
ax.axhline(1, ls='--', color=MUTED, lw=1.5); ax.text(9.6, 1.08, 'average', ha='right', fontsize=14, color=MUTED)
for i, val in enumerate(lift.values):
    ax.text(i, val + 0.06, f'{val:.1f}×', ha='center', fontsize=14, fontweight='bold', color=cols[i] if i <= 1 else MUTED)
clean_y(ax); ax.set_xlabel('decile of predicted probability (1 = highest)'); ax.tick_params(length=0)
save(fig, 'c11_lift.png')
print('cm', d['cm'].tolist(), 'thr', d['thr'])
